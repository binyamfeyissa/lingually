Set WshShell = CreateObject("WScript.Shell")
currentPath = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
htmlPath = currentPath & "\www\index.html"
userDataDir = WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Lingually\profile"
command = "msedge.exe --app=""" & htmlPath & """ --window-size=1140,780 --user-data-dir=""" & userDataDir & """"
WshShell.Run command, 0, False
