Set WshShell = CreateObject("WScript.Shell")
currentPath = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
htmlPath = currentPath & "\www\index.html?mode=quick-assist"
userDataDir = WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Lingually\profile"
command = "msedge.exe --app=""" & htmlPath & """ --window-size=480,600 --user-data-dir=""" & userDataDir & """"
WshShell.Run command, 0, False
