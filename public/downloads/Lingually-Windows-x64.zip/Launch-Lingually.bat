@echo off
title Lingually Desktop Workbench
echo Starting Lingually AI Writing Workbench...
start msedge.exe --app="%~dp0www\index.html" --window-size=1160,800 --user-data-dir="%LOCALAPPDATA%\Lingually\profile"
exit
