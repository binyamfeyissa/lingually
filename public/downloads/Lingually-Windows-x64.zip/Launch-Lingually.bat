@echo off
title Lingually Desktop Assistant
echo Starting Lingually AI Writing Workbench...
start msedge.exe --app="%~dp0www\index.html" --window-size=1140,780 --user-data-dir="%LOCALAPPDATA%\Lingually\profile"
exit
