@echo off
title Lingually Quick Assistant
start msedge.exe --app="%~dp0www\index.html?mode=quick-assist" --window-size=480,600 --user-data-dir="%LOCALAPPDATA%\Lingually\profile"
exit
