"use strict";
(() => {
  // apps/chrome-extension/src/shared-checker.ts
  var DETERMINISTIC_TYPOS = {
    teh: { replacement: "the", explanation: "Corrects typographical inversion." },
    recieve: { replacement: "receive", explanation: "Remember 'i' before 'e' except after 'c'." },
    seperate: { replacement: "separate", explanation: "Correct spelling contains 'para'." },
    definately: { replacement: "definitely", explanation: "Derived from 'finite'." },
    occured: { replacement: "occurred", explanation: "Double 'r' in occurred." },
    untill: { replacement: "until", explanation: "Until has a single 'l'." },
    truely: { replacement: "truly", explanation: "Drop the 'e' in truly." },
    wierd: { replacement: "weird", explanation: "Exception to the 'i before e' rule." },
    acheive: { replacement: "achieve", explanation: "'i' before 'e' in achieve." },
    goverment: { replacement: "government", explanation: "Includes 'n' from govern." },
    tommorrow: { replacement: "tomorrow", explanation: "One 'm', double 'r'." },
    alot: { replacement: "a lot", explanation: "'A lot' is two separate words." },
    noone: { replacement: "no one", explanation: "'No one' is written as two separate words." },
    beleive: { replacement: "believe", explanation: "'i' before 'e' in believe." },
    calender: { replacement: "calendar", explanation: "Spelled with 'ar' at the end." },
    accomodate: { replacement: "accommodate", explanation: "Double 'c' and double 'm'." },
    neccessary: { replacement: "necessary", explanation: "One 'c', double 's'." },
    embarass: { replacement: "embarrass", explanation: "Double 'r' and double 's'." }
  };
  var DETERMINISTIC_CONFUSIONS = [
    { pattern: /\bcould of\b/gi, replacement: "could have", explanation: "Use 'could have' instead of 'could of'." },
    { pattern: /\bshould of\b/gi, replacement: "should have", explanation: "Use 'should have' instead of 'should of'." },
    { pattern: /\bwould of\b/gi, replacement: "would have", explanation: "Use 'would have' instead of 'would of'." },
    { pattern: /\bsuppose to\b/gi, replacement: "supposed to", explanation: "The past participle 'supposed to' is required." },
    { pattern: /\buse to\b/gi, replacement: "used to", explanation: "The idiom is 'used to'." },
    { pattern: /\beach others\b/gi, replacement: "each other's", explanation: "Add an apostrophe for possessive 'each other's'." }
  ];
  var DETERMINISTIC_CLARITY = [
    { pattern: /\bin order to\b/gi, replacement: "to", explanation: "Simplify 'in order to' to simply 'to'." },
    { pattern: /\bat this point in time\b/gi, replacement: "now", explanation: "Concise alternative: 'now' or 'currently'." },
    { pattern: /\bdue to the fact that\b/gi, replacement: "because", explanation: "Simplify wordy phrase to 'because'." },
    { pattern: /\bhas the ability to\b/gi, replacement: "can", explanation: "Direct verb 'can' improves conciseness." },
    { pattern: /\bfor the purpose of\b/gi, replacement: "for", explanation: "Streamline 'for the purpose of' to 'for'." },
    { pattern: /\bin the event that\b/gi, replacement: "if", explanation: "Use 'if' for immediate clarity." },
    { pattern: /\ba large number of\b/gi, replacement: "many", explanation: "More direct and concise: 'many'." },
    { pattern: /\butilize\b/gi, replacement: "use", explanation: "'Use' is more direct than 'utilize'." },
    { pattern: /\butilizes\b/gi, replacement: "uses", explanation: "'Uses' is clearer than 'utilizes'." }
  ];
  var DETERMINISTIC_ENGAGEMENT = [
    { pattern: /\bvery good\b/gi, replacement: "exceptional", explanation: "Vivid alternative: 'exceptional' or 'superb'." },
    { pattern: /\bvery bad\b/gi, replacement: "terrible", explanation: "Expressive alternative: 'terrible' or 'dreadful'." },
    { pattern: /\bvery big\b/gi, replacement: "massive", explanation: "More vivid adjective: 'massive' or 'vast'." },
    { pattern: /\bvery small\b/gi, replacement: "tiny", explanation: "Dynamic alternative: 'tiny' or 'minuscule'." },
    { pattern: /\bvery important\b/gi, replacement: "crucial", explanation: "Stronger emphasis: 'crucial' or 'essential'." },
    { pattern: /\bvery happy\b/gi, replacement: "ecstatic", explanation: "Evocative alternative: 'ecstatic' or 'thrilled'." },
    { pattern: /\bvery sad\b/gi, replacement: "devastated", explanation: "Expressive alternative: 'devastated' or 'heartbroken'." }
  ];
  var DETERMINISTIC_DELIVERY = [
    { pattern: /\bi think that\b/gi, replacement: "", explanation: "Stating facts directly sounds more confident." },
    { pattern: /\bjust wondering if\b/gi, replacement: "could you", explanation: "Direct phrasing sounds more professional." },
    { pattern: /\bsorry to bother you,?\b/gi, replacement: "", explanation: "Polite but unnecessary hedging." },
    { pattern: /\byou should probably consider\b/gi, replacement: "we recommend", explanation: "Decisive phrasing sounds authoritative." }
  ];
  function runExtensionCheck(text, personalDictionary = /* @__PURE__ */ new Set()) {
    const suggestions2 = [];
    let idCounter = 1;
    if (!text || text.trim().length === 0) return suggestions2;
    const repeatedRegex = /\b([a-zA-Z]+)\s+\1\b/gi;
    let match;
    while ((match = repeatedRegex.exec(text)) !== null) {
      const rawWord = match[1];
      suggestions2.push({
        id: `ext_rep_${idCounter++}`,
        category: "correctness",
        originalText: match[0],
        replacementText: rawWord,
        explanation: `Repeated word '${rawWord}'. Remove the duplicate.`,
        offset: match.index,
        length: match[0].length
      });
    }
    const wordRegex = /\b[a-zA-Z]+\b/g;
    while ((match = wordRegex.exec(text)) !== null) {
      const rawWord = match[0];
      const lower = rawWord.toLowerCase();
      if (personalDictionary.has(lower)) continue;
      if (DETERMINISTIC_TYPOS[lower]) {
        const entry = DETERMINISTIC_TYPOS[lower];
        const isCapitalized = rawWord[0] === rawWord[0].toUpperCase() && rawWord[0] !== rawWord[0].toLowerCase();
        const replacement = isCapitalized ? entry.replacement.charAt(0).toUpperCase() + entry.replacement.slice(1) : entry.replacement;
        suggestions2.push({
          id: `ext_typo_${idCounter++}`,
          category: "correctness",
          originalText: rawWord,
          replacementText: replacement,
          explanation: entry.explanation,
          offset: match.index,
          length: rawWord.length
        });
      }
    }
    for (const item of DETERMINISTIC_CONFUSIONS) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions2.push({
          id: `ext_conf_${idCounter++}`,
          category: "correctness",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_CLARITY) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions2.push({
          id: `ext_clarity_${idCounter++}`,
          category: "clarity",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_ENGAGEMENT) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions2.push({
          id: `ext_eng_${idCounter++}`,
          category: "engagement",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_DELIVERY) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions2.push({
          id: `ext_del_${idCounter++}`,
          category: "delivery",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    return suggestions2.sort((a, b) => a.offset - b.offset);
  }

  // apps/chrome-extension/src/sidepanel.ts
  var currentText = "";
  var suggestions = [];
  document.addEventListener("DOMContentLoaded", () => {
    const inputEl = document.getElementById("sidepanel-input");
    const btnRunCheck = document.getElementById("btn-run-check");
    const btnFetchSelection = document.getElementById("btn-fetch-selection");
    const suggestionsList = document.getElementById("suggestions-list");
    const scoreBadge = document.getElementById("sidepanel-score");
    const tabs = document.querySelectorAll(".nav-tab");
    const tabPanes = document.querySelectorAll(".tab-pane");
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        tabs.forEach((t) => t.classList.remove("active"));
        tabPanes.forEach((p) => p.style.display = "none");
        tab.classList.add("active");
        const targetId = tab.getAttribute("data-tab");
        if (targetId) {
          const targetPane = document.getElementById(targetId);
          if (targetPane) targetPane.style.display = "block";
        }
      });
    });
    function renderSuggestions() {
      if (!suggestionsList) return;
      if (suggestions.length === 0) {
        suggestionsList.innerHTML = `<div class="empty-state">No issues detected! Your writing looks great.</div>`;
        scoreBadge.textContent = "100/100";
        scoreBadge.style.color = "#10b981";
        return;
      }
      const score = Math.max(50, 100 - suggestions.length * 6);
      scoreBadge.textContent = `${score}/100`;
      scoreBadge.style.color = score >= 85 ? "#10b981" : score >= 70 ? "#38bdf8" : "#fb7185";
      suggestionsList.innerHTML = suggestions.map(
        (s) => `
        <div class="suggestion-card" data-id="${s.id}">
          <div class="card-meta">
            <span class="pill pill-${s.category}">${s.category}</span>
          </div>
          <div style="font-size: 11px; color: #94a3b8; margin-bottom: 4px;">${s.explanation}</div>
          <div class="card-diff">
            <span style="text-decoration: line-through; color: #fb7185;">${s.originalText}</span>
            <span style="color: #64748b;">\u2192</span>
            <span style="color: #34d399; font-weight: 700;">${s.replacementText}</span>
          </div>
          <div style="display: flex; gap: 6px; margin-top: 8px;">
            <button class="btn btn-primary btn-accept" style="padding: 4px 8px; font-size: 11px;" data-id="${s.id}">Accept</button>
            <button class="btn btn-secondary btn-dismiss" style="padding: 4px 8px; font-size: 11px; margin-top: 0;" data-id="${s.id}">Dismiss</button>
          </div>
        </div>
      `
      ).join("");
      suggestionsList.querySelectorAll(".btn-accept").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-id");
          const s = suggestions.find((item) => item.id === id);
          if (s) {
            const before = currentText.slice(0, s.offset);
            const after = currentText.slice(s.offset + s.length);
            currentText = before + s.replacementText + after;
            inputEl.value = currentText;
            runCheck();
          }
        });
      });
      suggestionsList.querySelectorAll(".btn-dismiss").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-id");
          suggestions = suggestions.filter((item) => item.id !== id);
          renderSuggestions();
        });
      });
    }
    function runCheck() {
      currentText = inputEl.value;
      suggestions = runExtensionCheck(currentText);
      renderSuggestions();
    }
    btnRunCheck.addEventListener("click", runCheck);
    inputEl.addEventListener("input", () => {
      currentText = inputEl.value;
    });
    btnFetchSelection.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.id) {
        chrome.tabs.sendMessage(tab.id, { type: "GET_PAGE_SELECTION" }, (response) => {
          if (chrome.runtime.lastError || !response || !response.text) {
            chrome.scripting.executeScript(
              {
                target: { tabId: tab.id },
                func: () => window.getSelection()?.toString() || ""
              },
              (results) => {
                if (results && results[0] && results[0].result) {
                  inputEl.value = results[0].result;
                  runCheck();
                }
              }
            );
          } else {
            inputEl.value = response.text;
            runCheck();
          }
        });
      }
    });
    chrome.storage.session.get(["selectedText", "selectedTool"], (res) => {
      if (res.selectedText) {
        inputEl.value = String(res.selectedText);
        runCheck();
      }
    });
    const aiResultBox = document.getElementById("ai-result-box");
    const aiResultText = document.getElementById("ai-result-text");
    const btnCopyAi = document.getElementById("btn-copy-ai");
    function runAiTool(tool) {
      const text = inputEl.value.trim();
      if (!text) {
        alert("Please provide text first.");
        return;
      }
      let result = text;
      if (tool === "concise") {
        result = text.replace(/\bin order to\b/gi, "to").replace(/\bdue to the fact that\b/gi, "because").replace(/\bat this point in time\b/gi, "now").replace(/\bhas the ability to\b/gi, "can");
      } else if (tool === "formal") {
        result = "Furthermore, " + text.replace(/\bvery good\b/gi, "exceptional").replace(/\bdefinately\b/gi, "definitely");
      } else if (tool === "casual") {
        result = text.replace(/\bexceptional\b/gi, "great").replace(/\butilize\b/gi, "use");
      } else {
        result = text.replace(/\bdefinately\b/gi, "definitely").replace(/\bin order to\b/gi, "to");
      }
      aiResultText.textContent = result;
      aiResultBox.style.display = "block";
    }
    document.getElementById("tool-improve")?.addEventListener("click", () => runAiTool("improve"));
    document.getElementById("tool-paraphrase")?.addEventListener("click", () => runAiTool("paraphrase"));
    document.getElementById("tool-concise")?.addEventListener("click", () => runAiTool("concise"));
    document.getElementById("tool-formal")?.addEventListener("click", () => runAiTool("formal"));
    document.getElementById("tool-casual")?.addEventListener("click", () => runAiTool("casual"));
    btnCopyAi?.addEventListener("click", () => {
      if (aiResultText.textContent) {
        navigator.clipboard.writeText(aiResultText.textContent);
        btnCopyAi.textContent = "Copied!";
        setTimeout(() => btnCopyAi.textContent = "Copy to Clipboard", 1500);
      }
    });
  });
})();
