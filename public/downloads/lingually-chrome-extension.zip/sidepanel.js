"use strict";
(() => {
  // apps/chrome-extension/src/shared-checker.ts
  var DETERMINISTIC_TYPOS = {
    teh: { replacement: "the", explanation: "Corrects typographical inversion." },
    recieve: { replacement: "receive", explanation: "Remember 'i' before 'e' except after 'c'." },
    seperate: { replacement: "separate", explanation: "Correct spelling contains 'para'." },
    definately: { replacement: "definitely", explanation: "Derived from 'finite'." },
    occured: { replacement: "occurred", explanation: "Double 'r' in occurred." },
    untill: { replacement: "until", explanation: "Until has a single 'l'." },
    truely: { replacement: "truly", explanation: "Drop the 'e' in truly." },
    wierd: { replacement: "weird", explanation: "Exception to the 'i before e' rule." },
    acheive: { replacement: "achieve", explanation: "'i' before 'e' in achieve." },
    goverment: { replacement: "government", explanation: "Includes 'n' from govern." },
    tommorrow: { replacement: "tomorrow", explanation: "One 'm', double 'r'." },
    alot: { replacement: "a lot", explanation: "'A lot' is two separate words." },
    noone: { replacement: "no one", explanation: "'No one' is written as two separate words." },
    beleive: { replacement: "believe", explanation: "'i' before 'e' in believe." },
    calender: { replacement: "calendar", explanation: "Spelled with 'ar' at the end." },
    accomodate: { replacement: "accommodate", explanation: "Double 'c' and double 'm'." },
    neccessary: { replacement: "necessary", explanation: "One 'c', double 's'." },
    embarass: { replacement: "embarrass", explanation: "Double 'r' and double 's'." },
    wether: { replacement: "whether", explanation: "Use 'whether' for alternatives or 'weather' for climate." },
    witch: { replacement: "which", explanation: "Use 'which' for choices/clauses." },
    thier: { replacement: "their", explanation: "'e' before 'i' in their." },
    grammer: { replacement: "grammar", explanation: "Spelled with 'ar' at the end." },
    begining: { replacement: "beginning", explanation: "Double 'n' in beginning." },
    realy: { replacement: "really", explanation: "Double 'l' in really." },
    mispell: { replacement: "misspell", explanation: "Double 's' in misspell." },
    suprise: { replacement: "surprise", explanation: "Contains 'r' in the first syllable." },
    succesful: { replacement: "successful", explanation: "Double 'c' and double 's'." },
    publically: { replacement: "publicly", explanation: "Standard spelling is 'publicly'." },
    noticable: { replacement: "noticeable", explanation: "Retain the 'e' in noticeable." },
    independant: { replacement: "independent", explanation: "Ends in 'ent'." },
    gaurantee: { replacement: "guarantee", explanation: "'u' before 'a' in guarantee." },
    foriegn: { replacement: "foreign", explanation: "'e' before 'i' in foreign." },
    enviroment: { replacement: "environment", explanation: "Includes 'n' in iron." },
    dissapear: { replacement: "disappear", explanation: "One 's', double 'p'." },
    definate: { replacement: "definite", explanation: "Ends with 'ite'." },
    collegue: { replacement: "colleague", explanation: "Spelled 'colleague'." },
    catagory: { replacement: "category", explanation: "Spelled with 'e' in category." },
    alright: { replacement: "all right", explanation: "'All right' is preferred in formal writing." },
    basicly: { replacement: "basically", explanation: "Spelled 'basically'." },
    buisness: { replacement: "business", explanation: "'u' before 'i' in business." },
    concious: { replacement: "conscious", explanation: "Contains 'sc' in conscious." },
    dilema: { replacement: "dilemma", explanation: "Double 'm' in dilemma." },
    existance: { replacement: "existence", explanation: "Ends in 'ence'." },
    fascinating: { replacement: "fascinating", explanation: "Spelled with 'sc'." },
    greatful: { replacement: "grateful", explanation: "Spelled 'grateful' (not great)." },
    happend: { replacement: "happened", explanation: "Double 'p' in happened." },
    harrass: { replacement: "harass", explanation: "One 'r', double 's'." },
    humourous: { replacement: "humorous", explanation: "Drop 'u' in humorous." },
    immediatly: { replacement: "immediately", explanation: "Retain 'e' before 'ly'." },
    incidently: { replacement: "incidentally", explanation: "Contains 'al' before 'ly'." },
    interupt: { replacement: "interrupt", explanation: "Double 'r' in interrupt." },
    knowlege: { replacement: "knowledge", explanation: "Contains 'd' in knowledge." },
    liason: { replacement: "liaison", explanation: "Double 'i' in liaison." },
    millenium: { replacement: "millennium", explanation: "Double 'l' and double 'n'." },
    mischevious: { replacement: "mischievous", explanation: "Three syllables: mis-chie-vous." },
    paralell: { replacement: "parallel", explanation: "Double 'l' only in the middle." },
    posession: { replacement: "possession", explanation: "Double 's' twice in possession." },
    priviledge: { replacement: "privilege", explanation: "No 'd' in privilege." },
    pronounciation: { replacement: "pronunciation", explanation: "Spelled 'pronunciation' without 'o'." },
    questionaire: { replacement: "questionnaire", explanation: "Double 'n' in questionnaire." },
    recommand: { replacement: "recommend", explanation: "Spelled with 'e' in recommend." },
    refered: { replacement: "referred", explanation: "Double 'r' in referred." },
    relavant: { replacement: "relevant", explanation: "Spelled 'relevant'." },
    rythm: { replacement: "rhythm", explanation: "Contains 'h' after 'r' and 't'." },
    sieze: { replacement: "seize", explanation: "'e' before 'i' in seize." },
    succede: { replacement: "succeed", explanation: "Double 'e' in succeed." },
    tendancy: { replacement: "tendency", explanation: "Ends with 'ency'." },
    threshhold: { replacement: "threshold", explanation: "Single 'h' in threshold." },
    unfortunatly: { replacement: "unfortunately", explanation: "Retain 'e' in unfortunately." },
    vaccum: { replacement: "vacuum", explanation: "Single 'c', double 'u'." },
    visable: { replacement: "visible", explanation: "Spelled with 'i' in visible." },
    wierdly: { replacement: "weirdly", explanation: "Spelled 'weirdly'." }
  };
  var DETERMINISTIC_CONFUSIONS = [
    { pattern: /\bcould of\b/gi, replacement: "could have", explanation: "Use 'could have' instead of 'could of'." },
    { pattern: /\bshould of\b/gi, replacement: "should have", explanation: "Use 'should have' instead of 'should of'." },
    { pattern: /\bwould of\b/gi, replacement: "would have", explanation: "Use 'would have' instead of 'would of'." },
    { pattern: /\bmight of\b/gi, replacement: "might have", explanation: "Use 'might have' instead of 'might of'." },
    { pattern: /\bsuppose to\b/gi, replacement: "supposed to", explanation: "The past participle 'supposed to' is required." },
    { pattern: /\buse to\b/gi, replacement: "used to", explanation: "The idiom is 'used to'." },
    { pattern: /\beach others\b/gi, replacement: "each other's", explanation: "Add an apostrophe for possessive 'each other's'." },
    { pattern: /\bone anothers\b/gi, replacement: "one another's", explanation: "Add an apostrophe for possessive 'one another's'." },
    { pattern: /\bthere own\b/gi, replacement: "their own", explanation: "Use possessive 'their' with own." },
    { pattern: /\byour welcome\b/gi, replacement: "you're welcome", explanation: "Use 'you're' (you are welcome)." },
    { pattern: /\bits a\b/gi, replacement: "it's a", explanation: "Contraction 'it's' (it is a) is required." },
    { pattern: /\btheir is\b/gi, replacement: "there is", explanation: "Use 'there is' for existence." },
    { pattern: /\btheir are\b/gi, replacement: "there are", explanation: "Use 'there are' for existence." },
    { pattern: /\blose to much\b/gi, replacement: "lose too much", explanation: "'Too' means excessively." },
    { pattern: /\bto much\b/gi, replacement: "too much", explanation: "Use 'too' to mean an excessive amount." },
    { pattern: /\bto many\b/gi, replacement: "too many", explanation: "Use 'too' for excessive count." }
  ];
  var DETERMINISTIC_CLARITY = [
    { pattern: /\bin order to\b/gi, replacement: "to", explanation: "Simplify 'in order to' to simply 'to'." },
    { pattern: /\bat this point in time\b/gi, replacement: "now", explanation: "Concise alternative: 'now' or 'currently'." },
    { pattern: /\bdue to the fact that\b/gi, replacement: "because", explanation: "Simplify wordy phrase to 'because'." },
    { pattern: /\bhas the ability to\b/gi, replacement: "can", explanation: "Direct verb 'can' improves conciseness." },
    { pattern: /\bfor the purpose of\b/gi, replacement: "for", explanation: "Streamline 'for the purpose of' to 'for'." },
    { pattern: /\bin the event that\b/gi, replacement: "if", explanation: "Use 'if' for immediate clarity." },
    { pattern: /\ba large number of\b/gi, replacement: "many", explanation: "More direct and concise: 'many'." },
    { pattern: /\ba small number of\b/gi, replacement: "few", explanation: "Use 'few' instead of 'a small number of'." },
    { pattern: /\butilize\b/gi, replacement: "use", explanation: "'Use' is more direct than 'utilize'." },
    { pattern: /\butilizes\b/gi, replacement: "uses", explanation: "'Uses' is clearer than 'utilizes'." },
    { pattern: /\butilized\b/gi, replacement: "used", explanation: "'Used' is more natural." },
    { pattern: /\bat the present time\b/gi, replacement: "currently", explanation: "Use 'currently' or 'now'." },
    { pattern: /\bin spite of the fact that\b/gi, replacement: "although", explanation: "Simplify to 'although'." },
    { pattern: /\bwith the exception of\b/gi, replacement: "except", explanation: "Use 'except'." },
    { pattern: /\btake into consideration\b/gi, replacement: "consider", explanation: "Direct verb 'consider'." },
    { pattern: /\bmake a decision\b/gi, replacement: "decide", explanation: "Use the strong verb 'decide'." }
  ];
  var DETERMINISTIC_ENGAGEMENT = [
    { pattern: /\bvery good\b/gi, replacement: "exceptional", explanation: "Vivid alternative: 'exceptional' or 'superb'." },
    { pattern: /\bvery bad\b/gi, replacement: "terrible", explanation: "Expressive alternative: 'terrible' or 'dreadful'." },
    { pattern: /\bvery big\b/gi, replacement: "massive", explanation: "More vivid adjective: 'massive' or 'vast'." },
    { pattern: /\bvery small\b/gi, replacement: "tiny", explanation: "Dynamic alternative: 'tiny' or 'minuscule'." },
    { pattern: /\bvery important\b/gi, replacement: "crucial", explanation: "Stronger emphasis: 'crucial' or 'essential'." },
    { pattern: /\bvery happy\b/gi, replacement: "thrilled", explanation: "Evocative alternative: 'thrilled' or 'delighted'." },
    { pattern: /\bvery sad\b/gi, replacement: "devastated", explanation: "Expressive alternative: 'devastated'." },
    { pattern: /\bvery hard\b/gi, replacement: "challenging", explanation: "Refined adjective: 'demanding' or 'challenging'." }
  ];
  var DETERMINISTIC_DELIVERY = [
    { pattern: /\bI think that maybe\b/gi, replacement: "Perhaps", explanation: "Removes weak hedging for a more confident tone." },
    { pattern: /\bjust wondering if\b/gi, replacement: "could you", explanation: "Direct phrasing sounds more professional." },
    { pattern: /\bsorry to bother you,?\b/gi, replacement: "", explanation: "Polite but unnecessary hedging." },
    { pattern: /\byou should probably consider\b/gi, replacement: "we recommend", explanation: "Decisive phrasing sounds authoritative." }
  ];
  var COMMON_VOCABULARY = /* @__PURE__ */ new Set([
    "the",
    "be",
    "to",
    "of",
    "and",
    "a",
    "in",
    "that",
    "have",
    "i",
    "it",
    "for",
    "not",
    "on",
    "with",
    "he",
    "as",
    "you",
    "do",
    "at",
    "this",
    "but",
    "his",
    "by",
    "from",
    "they",
    "we",
    "say",
    "her",
    "she",
    "or",
    "an",
    "will",
    "my",
    "one",
    "all",
    "would",
    "there",
    "their",
    "what",
    "so",
    "up",
    "out",
    "if",
    "about",
    "who",
    "get",
    "which",
    "go",
    "me",
    "when",
    "make",
    "can",
    "like",
    "time",
    "no",
    "just",
    "him",
    "know",
    "take",
    "people",
    "into",
    "year",
    "your",
    "good",
    "some",
    "could",
    "them",
    "see",
    "other",
    "than",
    "then",
    "now",
    "look",
    "only",
    "come",
    "its",
    "over",
    "think",
    "also",
    "back",
    "after",
    "use",
    "two",
    "how",
    "our",
    "work",
    "first",
    "well",
    "way",
    "even",
    "new",
    "want",
    "because",
    "any",
    "these",
    "give",
    "day",
    "most",
    "us",
    "is",
    "are",
    "was",
    "were",
    "has",
    "had",
    "been",
    "am",
    "ready",
    "here",
    "help",
    "please",
    "write",
    "chat",
    "send",
    "message",
    "text",
    "search",
    "press",
    "open",
    "close",
    "view",
    "edit",
    "save",
    "delete",
    "create",
    "start",
    "stop",
    "check",
    "review",
    "find",
    "read",
    "run",
    "file",
    "page",
    "app",
    "web",
    "tool",
    "user",
    "input",
    "mode",
    "screen",
    "code",
    "data",
    "test",
    "issue",
    "error",
    "word",
    "line",
    "paragraph",
    "sentence",
    "grammar",
    "spell",
    "correct",
    "fix",
    "tone",
    "formal",
    "clear",
    "fast",
    "free",
    "key",
    "setting",
    "privacy",
    "model",
    "ai",
    "assistant",
    "lingually",
    "chrome",
    "system",
    "click",
    "select",
    "type",
    "today",
    "tomorrow",
    "yesterday",
    "always",
    "never",
    "often",
    "sometimes",
    "very",
    "much",
    "many",
    "few",
    "little",
    "big",
    "small",
    "high",
    "low",
    "long",
    "short",
    "right",
    "wrong",
    "true",
    "false",
    "yes",
    "sure",
    "fine",
    "great",
    "best",
    "better",
    "worse",
    "worst",
    "more",
    "less",
    "least",
    "again",
    "already",
    "still",
    "yet",
    "maybe",
    "perhaps",
    "actually",
    "really",
    "simply",
    "quite",
    "rather",
    "pretty",
    "almost",
    "enough",
    "too",
    "both",
    "either",
    "neither",
    "each",
    "every",
    "own",
    "same",
    "such",
    "why",
    "where",
    "how",
    "while",
    "since",
    "until",
    "before",
    "during",
    "through",
    "across",
    "under",
    "above",
    "between",
    "among",
    "against",
    "without",
    "within",
    "around",
    "behind",
    "beyond",
    "upon",
    "towards",
    "near",
    "off",
    "down",
    "left",
    "front",
    "side",
    "center",
    "hello",
    "hi",
    "hey",
    "thanks",
    "thank",
    "welcome",
    "sorry",
    "excuse",
    "pardon",
    "bye",
    "question",
    "answer",
    "reason",
    "problem",
    "solution",
    "result",
    "action",
    "change",
    "point",
    "thing",
    "place",
    "part",
    "number",
    "group",
    "fact",
    "idea",
    "story",
    "life",
    "world",
    "hand",
    "eye",
    "head",
    "face",
    "voice",
    "sound",
    "mind",
    "heart",
    "body",
    "name",
    "call",
    "keep",
    "let",
    "begin",
    "seem",
    "help",
    "talk",
    "turn",
    "start",
    "show",
    "hear",
    "play",
    "move",
    "live",
    "believe",
    "hold",
    "bring",
    "happen",
    "must",
    "write",
    "provide",
    "sit",
    "stand",
    "lose",
    "pay",
    "meet",
    "include",
    "continue",
    "set",
    "learn",
    "lead",
    "understand",
    "watch",
    "follow",
    "stop",
    "allow",
    "add",
    "spend",
    "grow",
    "open",
    "walk",
    "win",
    "offer",
    "remember",
    "love",
    "consider",
    "appear",
    "buy",
    "wait",
    "serve",
    "die",
    "send",
    "expect",
    "build",
    "stay",
    "fall",
    "cut",
    "reach",
    "kill",
    "remain",
    "suggest",
    "raise",
    "pass",
    "sell",
    "require",
    "report",
    "decide",
    "pull"
  ]);
  function levenshteinDistance(a, b) {
    const m = a.length;
    const n = b.length;
    const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        if (a[i - 1] === b[j - 1]) {
          dp[i][j] = dp[i - 1][j - 1];
        } else {
          dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
        }
      }
    }
    return dp[m][n];
  }
  function findClosestWord(target) {
    let closest = null;
    let minDistance = 3;
    for (const word of COMMON_VOCABULARY) {
      if (Math.abs(word.length - target.length) > 2) continue;
      const dist = levenshteinDistance(target, word);
      if (dist < minDistance) {
        minDistance = dist;
        closest = word;
        if (dist === 1) break;
      }
    }
    return closest;
  }
  function isLikelyGibberishOrMisspelling(word) {
    if (word.length < 3) return false;
    const lower = word.toLowerCase();
    if (COMMON_VOCABULARY.has(lower) || DETERMINISTIC_TYPOS[lower]) return false;
    const rootS = lower.endsWith("s") ? lower.slice(0, -1) : "";
    const rootEd = lower.endsWith("ed") ? lower.slice(0, -2) : "";
    const rootIng = lower.endsWith("ing") ? lower.slice(0, -3) : "";
    const rootLy = lower.endsWith("ly") ? lower.slice(0, -2) : "";
    if (rootS && COMMON_VOCABULARY.has(rootS) || rootEd && COMMON_VOCABULARY.has(rootEd) || rootIng && COMMON_VOCABULARY.has(rootIng) || rootLy && COMMON_VOCABULARY.has(rootLy)) {
      return false;
    }
    if (/([a-zA-Z])\1\1/.test(lower)) return true;
    if (/^(hh|vv|jj|qq|xx|ww|yy|ii|uu)/.test(lower)) return true;
    if (/(hgg|ggu|zzk|xkz|qq|q[^u]|ii|uu)/.test(lower)) return true;
    if (!/[aeiouy]/.test(lower)) return true;
    if (lower.length >= 4 && !COMMON_VOCABULARY.has(lower)) {
      return true;
    }
    return false;
  }
  function runExtensionCheck(text, personalDictionary = /* @__PURE__ */ new Set()) {
    const suggestions2 = [];
    let idCounter = 1;
    if (!text || text.trim().length === 0) return suggestions2;
    const standaloneIRegex = /(^|[\s(])i([\s),.?!]|$)/g;
    let match;
    while ((match = standaloneIRegex.exec(text)) !== null) {
      const prefix = match[1];
      const offset = match.index + prefix.length;
      suggestions2.push({
        id: `ext_i_${idCounter++}`,
        category: "correctness",
        originalText: "i",
        replacementText: "I",
        explanation: "Capitalize the standalone personal pronoun 'I'.",
        offset,
        length: 1
      });
    }
    const repeatedRegex = /\b([a-zA-Z]+)\s+\1\b/gi;
    while ((match = repeatedRegex.exec(text)) !== null) {
      const rawWord = match[1];
      suggestions2.push({
        id: `ext_rep_${idCounter++}`,
        category: "correctness",
        originalText: match[0],
        replacementText: rawWord,
        explanation: `Repeated word '${rawWord}'. Remove the duplicate.`,
        offset: match.index,
        length: match[0].length
      });
    }
    const wordRegex = /\b[a-zA-Z]+\b/g;
    while ((match = wordRegex.exec(text)) !== null) {
      const rawWord = match[0];
      const lower = rawWord.toLowerCase();
      if (personalDictionary.has(lower)) continue;
      if (DETERMINISTIC_TYPOS[lower]) {
        const entry = DETERMINISTIC_TYPOS[lower];
        const isCapitalized = rawWord[0] === rawWord[0].toUpperCase() && rawWord[0] !== rawWord[0].toLowerCase();
        const replacement = isCapitalized ? entry.replacement.charAt(0).toUpperCase() + entry.replacement.slice(1) : entry.replacement;
        suggestions2.push({
          id: `ext_typo_${idCounter++}`,
          category: "correctness",
          originalText: rawWord,
          replacementText: replacement,
          explanation: entry.explanation,
          offset: match.index,
          length: rawWord.length
        });
        continue;
      }
      if (isLikelyGibberishOrMisspelling(rawWord)) {
        const closest = findClosestWord(lower);
        const isCap = rawWord[0] === rawWord[0].toUpperCase();
        const rep = closest ? isCap ? closest.charAt(0).toUpperCase() + closest.slice(1) : closest : "check spelling";
        suggestions2.push({
          id: `ext_gib_${idCounter++}`,
          category: "correctness",
          originalText: rawWord,
          replacementText: rep,
          explanation: closest ? `Possible misspelling. Did you mean '${rep}'?` : `Unrecognized word '${rawWord}'. Check spelling or add to dictionary.`,
          offset: match.index,
          length: rawWord.length
        });
      }
    }
    for (const item of DETERMINISTIC_CONFUSIONS) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions2.push({
          id: `ext_conf_${idCounter++}`,
          category: "correctness",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_CLARITY) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions2.push({
          id: `ext_clarity_${idCounter++}`,
          category: "clarity",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_ENGAGEMENT) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions2.push({
          id: `ext_eng_${idCounter++}`,
          category: "engagement",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_DELIVERY) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions2.push({
          id: `ext_del_${idCounter++}`,
          category: "delivery",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    return suggestions2.sort((a, b) => a.offset - b.offset);
  }

  // apps/chrome-extension/src/sidepanel.ts
  var currentText = "";
  var suggestions = [];
  document.addEventListener("DOMContentLoaded", () => {
    const inputEl = document.getElementById("sidepanel-input");
    const btnRunCheck = document.getElementById("btn-run-check");
    const btnFetchSelection = document.getElementById("btn-fetch-selection");
    const suggestionsList = document.getElementById("suggestions-list");
    const scoreBadge = document.getElementById("sidepanel-score");
    const tabs = document.querySelectorAll(".nav-tab");
    const tabPanes = document.querySelectorAll(".tab-pane");
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        tabs.forEach((t) => t.classList.remove("active"));
        tabPanes.forEach((p) => p.style.display = "none");
        tab.classList.add("active");
        const targetId = tab.getAttribute("data-tab");
        if (targetId) {
          const targetPane = document.getElementById(targetId);
          if (targetPane) targetPane.style.display = "block";
        }
      });
    });
    function renderSuggestions() {
      if (!suggestionsList) return;
      if (suggestions.length === 0) {
        suggestionsList.innerHTML = `<div class="empty-state">No issues detected! Your writing looks great.</div>`;
        scoreBadge.textContent = "100/100";
        scoreBadge.style.color = "#10b981";
        return;
      }
      const score = Math.max(50, 100 - suggestions.length * 6);
      scoreBadge.textContent = `${score}/100`;
      scoreBadge.style.color = score >= 85 ? "#10b981" : score >= 70 ? "#38bdf8" : "#fb7185";
      suggestionsList.innerHTML = suggestions.map(
        (s) => `
        <div class="suggestion-card" data-id="${s.id}">
          <div class="card-meta">
            <span class="pill pill-${s.category}">${s.category}</span>
          </div>
          <div style="font-size: 11px; color: #94a3b8; margin-bottom: 4px;">${s.explanation}</div>
          <div class="card-diff">
            <span style="text-decoration: line-through; color: #fb7185;">${s.originalText}</span>
            <span style="color: #64748b;">\u2192</span>
            <span style="color: #34d399; font-weight: 700;">${s.replacementText}</span>
          </div>
          <div style="display: flex; gap: 6px; margin-top: 8px;">
            <button class="btn btn-primary btn-accept" style="padding: 4px 8px; font-size: 11px;" data-id="${s.id}">Accept</button>
            <button class="btn btn-secondary btn-dismiss" style="padding: 4px 8px; font-size: 11px; margin-top: 0;" data-id="${s.id}">Dismiss</button>
          </div>
        </div>
      `
      ).join("");
      suggestionsList.querySelectorAll(".btn-accept").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-id");
          const s = suggestions.find((item) => item.id === id);
          if (s) {
            const before = currentText.slice(0, s.offset);
            const after = currentText.slice(s.offset + s.length);
            currentText = before + s.replacementText + after;
            inputEl.value = currentText;
            runCheck();
          }
        });
      });
      suggestionsList.querySelectorAll(".btn-dismiss").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-id");
          suggestions = suggestions.filter((item) => item.id !== id);
          renderSuggestions();
        });
      });
    }
    function runCheck() {
      currentText = inputEl.value;
      suggestions = runExtensionCheck(currentText);
      renderSuggestions();
    }
    btnRunCheck.addEventListener("click", runCheck);
    inputEl.addEventListener("input", () => {
      currentText = inputEl.value;
    });
    btnFetchSelection.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.id) {
        chrome.tabs.sendMessage(tab.id, { type: "GET_PAGE_SELECTION" }, (response) => {
          if (chrome.runtime.lastError || !response || !response.text) {
            chrome.scripting.executeScript(
              {
                target: { tabId: tab.id },
                func: () => window.getSelection()?.toString() || ""
              },
              (results) => {
                if (results && results[0] && results[0].result) {
                  inputEl.value = results[0].result;
                  runCheck();
                }
              }
            );
          } else {
            inputEl.value = response.text;
            runCheck();
          }
        });
      }
    });
    chrome.storage.session.get(["selectedText", "selectedTool"], (res) => {
      if (res.selectedText) {
        inputEl.value = String(res.selectedText);
        runCheck();
      }
    });
    const aiResultBox = document.getElementById("ai-result-box");
    const aiResultText = document.getElementById("ai-result-text");
    const btnCopyAi = document.getElementById("btn-copy-ai");
    function runAiTool(tool) {
      const text = inputEl.value.trim();
      if (!text) {
        alert("Please provide text first.");
        return;
      }
      let result = text;
      if (tool === "concise") {
        result = text.replace(/\bin order to\b/gi, "to").replace(/\bdue to the fact that\b/gi, "because").replace(/\bat this point in time\b/gi, "now").replace(/\bhas the ability to\b/gi, "can");
      } else if (tool === "formal") {
        result = "Furthermore, " + text.replace(/\bvery good\b/gi, "exceptional").replace(/\bdefinately\b/gi, "definitely");
      } else if (tool === "casual") {
        result = text.replace(/\bexceptional\b/gi, "great").replace(/\butilize\b/gi, "use");
      } else {
        result = text.replace(/\bdefinately\b/gi, "definitely").replace(/\bin order to\b/gi, "to");
      }
      aiResultText.textContent = result;
      aiResultBox.style.display = "block";
    }
    document.getElementById("tool-improve")?.addEventListener("click", () => runAiTool("improve"));
    document.getElementById("tool-paraphrase")?.addEventListener("click", () => runAiTool("paraphrase"));
    document.getElementById("tool-concise")?.addEventListener("click", () => runAiTool("concise"));
    document.getElementById("tool-formal")?.addEventListener("click", () => runAiTool("formal"));
    document.getElementById("tool-casual")?.addEventListener("click", () => runAiTool("casual"));
    btnCopyAi?.addEventListener("click", () => {
      if (aiResultText.textContent) {
        navigator.clipboard.writeText(aiResultText.textContent);
        btnCopyAi.textContent = "Copied!";
        setTimeout(() => btnCopyAi.textContent = "Copy to Clipboard", 1500);
      }
    });
  });
})();
