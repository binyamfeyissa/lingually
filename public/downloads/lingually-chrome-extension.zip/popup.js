"use strict";
(() => {
  // apps/chrome-extension/src/popup.ts
  document.addEventListener("DOMContentLoaded", () => {
    const toggleEnabled = document.getElementById("toggle-enabled");
    const btnSidepanel = document.getElementById("btn-sidepanel");
    const btnEditor = document.getElementById("btn-editor");
    const btnOptions = document.getElementById("btn-options");
    chrome.storage.sync.get(["lingually_enabled"], (res) => {
      toggleEnabled.checked = res.lingually_enabled !== false;
    });
    toggleEnabled.addEventListener("change", () => {
      chrome.storage.sync.set({ lingually_enabled: toggleEnabled.checked });
    });
    btnSidepanel.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.windowId) {
        chrome.sidePanel.open({ windowId: tab.windowId });
        window.close();
      }
    });
    btnEditor.addEventListener("click", () => {
      chrome.storage.sync.get(["lingually_workbench_url"], (res) => {
        const targetUrl = res.lingually_workbench_url || "https://lingually-os.vercel.app/editor";
        chrome.tabs.create({ url: targetUrl });
        window.close();
      });
    });
    btnOptions.addEventListener("click", () => {
      chrome.runtime.openOptionsPage();
      window.close();
    });
  });
})();
