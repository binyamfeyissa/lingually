// apps/chrome-extension/src/background.ts
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(["lingually_enabled", "lingually_goals"], (res) => {
    if (res.lingually_enabled === void 0) {
      chrome.storage.sync.set({
        lingually_enabled: true,
        lingually_goals: {
          audience: "general",
          formality: "neutral",
          domain: "general",
          intent: "inform"
        }
      });
    }
  });
  chrome.contextMenus.create({
    id: "lingually_root",
    title: "Lingually Writing Assistant",
    contexts: ["selection", "editable"]
  });
  chrome.contextMenus.create({
    parentId: "lingually_root",
    id: "lingually_improve",
    title: "\u2728 Improve Writing",
    contexts: ["selection"]
  });
  chrome.contextMenus.create({
    parentId: "lingually_root",
    id: "lingually_paraphrase",
    title: "\u{1F504} Paraphrase Selection",
    contexts: ["selection"]
  });
  chrome.contextMenus.create({
    parentId: "lingually_root",
    id: "lingually_summarize",
    title: "\u{1F4DD} Summarize Selection",
    contexts: ["selection"]
  });
  chrome.contextMenus.create({
    parentId: "lingually_root",
    id: "lingually_sidepanel",
    title: "\u{1F4D6} Open Side Panel",
    contexts: ["all"]
  });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;
  if (info.menuItemId === "lingually_sidepanel") {
    chrome.sidePanel.open({ windowId: tab.windowId });
    return;
  }
  if (info.selectionText) {
    chrome.storage.session.set({
      selectedText: info.selectionText,
      selectedTool: info.menuItemId.toString().replace("lingually_", ""),
      timestamp: Date.now()
    });
    chrome.sidePanel.open({ windowId: tab.windowId });
    chrome.tabs.sendMessage(tab.id, {
      type: "LINGUALLY_CONTEXT_MENU_ACTION",
      tool: info.menuItemId,
      text: info.selectionText
    }).catch(() => {
    });
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "OPEN_SIDEPANEL") {
    if (sender.tab && sender.tab.windowId) {
      chrome.sidePanel.open({ windowId: sender.tab.windowId });
      sendResponse({ success: true });
    }
  } else if (message.type === "GET_EXTENSION_STATUS") {
    chrome.storage.sync.get(["lingually_enabled"], (res) => {
      sendResponse({ enabled: res.lingually_enabled !== false });
    });
    return true;
  }
});
