"use strict";
(() => {
  // apps/chrome-extension/src/options.ts
  document.addEventListener("DOMContentLoaded", () => {
    const providerSelect = document.getElementById("provider-select");
    const apiKeyInput = document.getElementById("api-key-input");
    const btnSaveKeys = document.getElementById("btn-save-keys");
    const saveStatus = document.getElementById("save-status");
    const dictInput = document.getElementById("dict-input");
    const btnAddDict = document.getElementById("btn-add-dict");
    const dictList = document.getElementById("dict-list");
    let apiKeys = {};
    let dictionaryWords = [];
    chrome.storage.sync.get(["lingually_provider", "lingually_api_keys", "lingually_dictionary"], (res) => {
      if (res.lingually_provider) {
        providerSelect.value = String(res.lingually_provider);
      }
      if (res.lingually_api_keys) {
        apiKeys = res.lingually_api_keys || {};
        apiKeyInput.value = apiKeys[providerSelect.value] || "";
      }
      if (Array.isArray(res.lingually_dictionary)) {
        dictionaryWords = res.lingually_dictionary;
        renderDictionary();
      }
    });
    providerSelect.addEventListener("change", () => {
      apiKeyInput.value = apiKeys[providerSelect.value] || "";
    });
    btnSaveKeys.addEventListener("click", () => {
      const selectedProvider = providerSelect.value;
      apiKeys[selectedProvider] = apiKeyInput.value.trim();
      chrome.storage.sync.set(
        {
          lingually_provider: selectedProvider,
          lingually_api_keys: apiKeys
        },
        () => {
          saveStatus.style.display = "block";
          setTimeout(() => {
            saveStatus.style.display = "none";
          }, 2e3);
        }
      );
    });
    function renderDictionary() {
      dictList.innerHTML = "";
      dictionaryWords.forEach((word) => {
        const pill = document.createElement("span");
        pill.className = "dict-pill";
        pill.innerHTML = `
        <span>${word}</span>
        <span class="dict-del" data-word="${word}">&times;</span>
      `;
        dictList.appendChild(pill);
      });
      dictList.querySelectorAll(".dict-del").forEach((delBtn) => {
        delBtn.addEventListener("click", () => {
          const wordToRemove = delBtn.getAttribute("data-word");
          if (wordToRemove) {
            dictionaryWords = dictionaryWords.filter((w) => w !== wordToRemove);
            chrome.storage.sync.set({ lingually_dictionary: dictionaryWords }, () => {
              renderDictionary();
            });
          }
        });
      });
    }
    function addWord() {
      const word = dictInput.value.trim().toLowerCase();
      if (word && !dictionaryWords.includes(word)) {
        dictionaryWords.push(word);
        chrome.storage.sync.set({ lingually_dictionary: dictionaryWords }, () => {
          dictInput.value = "";
          renderDictionary();
        });
      }
    }
    btnAddDict.addEventListener("click", addWord);
    dictInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addWord();
      }
    });
  });
})();
