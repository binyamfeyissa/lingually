"use strict";
(() => {
  // apps/chrome-extension/src/shared-checker.ts
  var DETERMINISTIC_TYPOS = {
    teh: { replacement: "the", explanation: "Corrects typographical inversion." },
    recieve: { replacement: "receive", explanation: "Remember 'i' before 'e' except after 'c'." },
    seperate: { replacement: "separate", explanation: "Correct spelling contains 'para'." },
    definately: { replacement: "definitely", explanation: "Derived from 'finite'." },
    occured: { replacement: "occurred", explanation: "Double 'r' in occurred." },
    untill: { replacement: "until", explanation: "Until has a single 'l'." },
    truely: { replacement: "truly", explanation: "Drop the 'e' in truly." },
    wierd: { replacement: "weird", explanation: "Exception to the 'i before e' rule." },
    acheive: { replacement: "achieve", explanation: "'i' before 'e' in achieve." },
    goverment: { replacement: "government", explanation: "Includes 'n' from govern." },
    tommorrow: { replacement: "tomorrow", explanation: "One 'm', double 'r'." },
    alot: { replacement: "a lot", explanation: "'A lot' is two separate words." },
    noone: { replacement: "no one", explanation: "'No one' is written as two separate words." },
    beleive: { replacement: "believe", explanation: "'i' before 'e' in believe." },
    calender: { replacement: "calendar", explanation: "Spelled with 'ar' at the end." },
    accomodate: { replacement: "accommodate", explanation: "Double 'c' and double 'm'." },
    neccessary: { replacement: "necessary", explanation: "One 'c', double 's'." },
    embarass: { replacement: "embarrass", explanation: "Double 'r' and double 's'." }
  };
  var DETERMINISTIC_CONFUSIONS = [
    { pattern: /\bcould of\b/gi, replacement: "could have", explanation: "Use 'could have' instead of 'could of'." },
    { pattern: /\bshould of\b/gi, replacement: "should have", explanation: "Use 'should have' instead of 'should of'." },
    { pattern: /\bwould of\b/gi, replacement: "would have", explanation: "Use 'would have' instead of 'would of'." },
    { pattern: /\bsuppose to\b/gi, replacement: "supposed to", explanation: "The past participle 'supposed to' is required." },
    { pattern: /\buse to\b/gi, replacement: "used to", explanation: "The idiom is 'used to'." },
    { pattern: /\beach others\b/gi, replacement: "each other's", explanation: "Add an apostrophe for possessive 'each other's'." }
  ];
  var DETERMINISTIC_CLARITY = [
    { pattern: /\bin order to\b/gi, replacement: "to", explanation: "Simplify 'in order to' to simply 'to'." },
    { pattern: /\bat this point in time\b/gi, replacement: "now", explanation: "Concise alternative: 'now' or 'currently'." },
    { pattern: /\bdue to the fact that\b/gi, replacement: "because", explanation: "Simplify wordy phrase to 'because'." },
    { pattern: /\bhas the ability to\b/gi, replacement: "can", explanation: "Direct verb 'can' improves conciseness." },
    { pattern: /\bfor the purpose of\b/gi, replacement: "for", explanation: "Streamline 'for the purpose of' to 'for'." },
    { pattern: /\bin the event that\b/gi, replacement: "if", explanation: "Use 'if' for immediate clarity." },
    { pattern: /\ba large number of\b/gi, replacement: "many", explanation: "More direct and concise: 'many'." },
    { pattern: /\butilize\b/gi, replacement: "use", explanation: "'Use' is more direct than 'utilize'." },
    { pattern: /\butilizes\b/gi, replacement: "uses", explanation: "'Uses' is clearer than 'utilizes'." }
  ];
  var DETERMINISTIC_ENGAGEMENT = [
    { pattern: /\bvery good\b/gi, replacement: "exceptional", explanation: "Vivid alternative: 'exceptional' or 'superb'." },
    { pattern: /\bvery bad\b/gi, replacement: "terrible", explanation: "Expressive alternative: 'terrible' or 'dreadful'." },
    { pattern: /\bvery big\b/gi, replacement: "massive", explanation: "More vivid adjective: 'massive' or 'vast'." },
    { pattern: /\bvery small\b/gi, replacement: "tiny", explanation: "Dynamic alternative: 'tiny' or 'minuscule'." },
    { pattern: /\bvery important\b/gi, replacement: "crucial", explanation: "Stronger emphasis: 'crucial' or 'essential'." },
    { pattern: /\bvery happy\b/gi, replacement: "ecstatic", explanation: "Evocative alternative: 'ecstatic' or 'thrilled'." },
    { pattern: /\bvery sad\b/gi, replacement: "devastated", explanation: "Expressive alternative: 'devastated' or 'heartbroken'." }
  ];
  var DETERMINISTIC_DELIVERY = [
    { pattern: /\bi think that\b/gi, replacement: "", explanation: "Stating facts directly sounds more confident." },
    { pattern: /\bjust wondering if\b/gi, replacement: "could you", explanation: "Direct phrasing sounds more professional." },
    { pattern: /\bsorry to bother you,?\b/gi, replacement: "", explanation: "Polite but unnecessary hedging." },
    { pattern: /\byou should probably consider\b/gi, replacement: "we recommend", explanation: "Decisive phrasing sounds authoritative." }
  ];
  function runExtensionCheck(text, personalDictionary2 = /* @__PURE__ */ new Set()) {
    const suggestions = [];
    let idCounter = 1;
    if (!text || text.trim().length === 0) return suggestions;
    const repeatedRegex = /\b([a-zA-Z]+)\s+\1\b/gi;
    let match;
    while ((match = repeatedRegex.exec(text)) !== null) {
      const rawWord = match[1];
      suggestions.push({
        id: `ext_rep_${idCounter++}`,
        category: "correctness",
        originalText: match[0],
        replacementText: rawWord,
        explanation: `Repeated word '${rawWord}'. Remove the duplicate.`,
        offset: match.index,
        length: match[0].length
      });
    }
    const wordRegex = /\b[a-zA-Z]+\b/g;
    while ((match = wordRegex.exec(text)) !== null) {
      const rawWord = match[0];
      const lower = rawWord.toLowerCase();
      if (personalDictionary2.has(lower)) continue;
      if (DETERMINISTIC_TYPOS[lower]) {
        const entry = DETERMINISTIC_TYPOS[lower];
        const isCapitalized = rawWord[0] === rawWord[0].toUpperCase() && rawWord[0] !== rawWord[0].toLowerCase();
        const replacement = isCapitalized ? entry.replacement.charAt(0).toUpperCase() + entry.replacement.slice(1) : entry.replacement;
        suggestions.push({
          id: `ext_typo_${idCounter++}`,
          category: "correctness",
          originalText: rawWord,
          replacementText: replacement,
          explanation: entry.explanation,
          offset: match.index,
          length: rawWord.length
        });
      }
    }
    for (const item of DETERMINISTIC_CONFUSIONS) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_conf_${idCounter++}`,
          category: "correctness",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_CLARITY) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_clarity_${idCounter++}`,
          category: "clarity",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_ENGAGEMENT) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_eng_${idCounter++}`,
          category: "engagement",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_DELIVERY) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_del_${idCounter++}`,
          category: "delivery",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    return suggestions.sort((a, b) => a.offset - b.offset);
  }

  // apps/chrome-extension/src/content.ts
  var activeElement = null;
  var currentSuggestions = [];
  var personalDictionary = /* @__PURE__ */ new Set();
  var isExtensionEnabled = true;
  var debounceTimer = null;
  var badgeElement = null;
  var cardElement = null;
  chrome.storage.sync.get(["lingually_enabled", "lingually_dictionary"], (res) => {
    if (res.lingually_enabled !== void 0) {
      isExtensionEnabled = Boolean(res.lingually_enabled);
    }
    if (Array.isArray(res.lingually_dictionary)) {
      personalDictionary = new Set(res.lingually_dictionary.map((w) => w.toLowerCase()));
    }
  });
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.lingually_enabled) {
      isExtensionEnabled = Boolean(changes.lingually_enabled.newValue);
      if (!isExtensionEnabled) {
        removeUI();
      }
    }
    if (changes.lingually_dictionary) {
      const list = changes.lingually_dictionary.newValue || [];
      personalDictionary = new Set(list.map((w) => w.toLowerCase()));
      if (activeElement) {
        checkActiveElement();
      }
    }
  });
  function isEditable(el) {
    if (!el) return false;
    const tag = el.tagName.toLowerCase();
    if (tag === "textarea") return true;
    if (tag === "input") {
      const inputType = el.type.toLowerCase();
      return ["text", "search", "email", "url", ""].includes(inputType);
    }
    return el.isContentEditable || el.getAttribute("contenteditable") === "true";
  }
  function getText(el) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      return el.value;
    }
    return el.innerText || el.textContent || "";
  }
  function setText(el, newText) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      const start = el.selectionStart;
      const end = el.selectionEnd;
      el.value = newText;
      if (start !== null && end !== null) {
        el.setSelectionRange(start, end);
      }
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else if (el.isContentEditable) {
      el.innerText = newText;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  function removeUI() {
    if (badgeElement && badgeElement.parentNode) {
      badgeElement.parentNode.removeChild(badgeElement);
      badgeElement = null;
    }
    if (cardElement && cardElement.parentNode) {
      cardElement.parentNode.removeChild(cardElement);
      cardElement = null;
    }
  }
  function updateBadgePosition() {
    if (!badgeElement || !activeElement) return;
    const rect = activeElement.getBoundingClientRect();
    const scrollX = window.scrollX || window.pageXOffset;
    const scrollY = window.scrollY || window.pageYOffset;
    badgeElement.style.top = `${scrollY + rect.bottom - 32}px`;
    badgeElement.style.left = `${scrollX + rect.right - 90}px`;
  }
  function renderBadge(count) {
    if (!activeElement || !isExtensionEnabled) {
      removeUI();
      return;
    }
    if (!badgeElement) {
      badgeElement = document.createElement("div");
      badgeElement.className = "lingually-ext-badge";
      badgeElement.addEventListener("click", (e) => {
        e.stopPropagation();
        e.preventDefault();
        if (currentSuggestions.length > 0) {
          showSuggestionCard(currentSuggestions[0]);
        } else {
          chrome.runtime.sendMessage({ type: "OPEN_SIDEPANEL" });
        }
      });
      document.body.appendChild(badgeElement);
    }
    badgeElement.className = `lingually-ext-badge ${count > 0 ? "lingually-ext-badge-has-issues" : ""}`;
    badgeElement.innerHTML = `
    <span class="lingually-ext-badge-dot"></span>
    <span>${count > 0 ? `${count} issue${count > 1 ? "s" : ""}` : "Lingually"}</span>
  `;
    updateBadgePosition();
  }
  function showSuggestionCard(s) {
    if (!activeElement) return;
    if (cardElement && cardElement.parentNode) {
      cardElement.parentNode.removeChild(cardElement);
      cardElement = null;
    }
    cardElement = document.createElement("div");
    cardElement.className = "lingually-ext-card";
    const rect = activeElement.getBoundingClientRect();
    const scrollX = window.scrollX || window.pageXOffset;
    const scrollY = window.scrollY || window.pageYOffset;
    cardElement.style.top = `${scrollY + rect.top + 20}px`;
    cardElement.style.left = `${scrollX + Math.min(rect.left + 20, window.innerWidth - 360)}px`;
    cardElement.innerHTML = `
    <div class="lingually-ext-header">
      <span class="lingually-ext-category lingually-cat-${s.category}">${s.category}</span>
      <span style="font-size: 11px; color: #64748b;">${currentSuggestions.indexOf(s) + 1} of ${currentSuggestions.length}</span>
    </div>
    <div class="lingually-ext-explanation">${s.explanation}</div>
    <div class="lingually-ext-diff">
      <span class="lingually-ext-original">${s.originalText}</span>
      <span class="lingually-ext-arrow">\u2192</span>
      <span class="lingually-ext-replacement">${s.replacementText}</span>
    </div>
    <div class="lingually-ext-actions">
      <button class="lingually-ext-btn-accept" id="lingually-accept-btn">Accept</button>
      <button class="lingually-ext-btn-dismiss" id="lingually-dismiss-btn">Dismiss</button>
    </div>
    <button class="lingually-ext-btn-dict" id="lingually-dict-btn">Add "${s.originalText}" to dictionary</button>
  `;
    document.body.appendChild(cardElement);
    const acceptBtn = cardElement.querySelector("#lingually-accept-btn");
    const dismissBtn = cardElement.querySelector("#lingually-dismiss-btn");
    const dictBtn = cardElement.querySelector("#lingually-dict-btn");
    acceptBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      applySuggestion(s);
    });
    dismissBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      dismissSuggestion(s);
    });
    dictBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      addToDictionary(s.originalText);
    });
  }
  function applySuggestion(s) {
    if (!activeElement) return;
    const fullText = getText(activeElement);
    const before = fullText.slice(0, s.offset);
    const after = fullText.slice(s.offset + s.length);
    const updated = before + s.replacementText + after;
    setText(activeElement, updated);
    checkActiveElement();
  }
  function dismissSuggestion(s) {
    currentSuggestions = currentSuggestions.filter((item) => item.id !== s.id);
    renderBadge(currentSuggestions.length);
    if (currentSuggestions.length > 0) {
      showSuggestionCard(currentSuggestions[0]);
    } else if (cardElement && cardElement.parentNode) {
      cardElement.parentNode.removeChild(cardElement);
      cardElement = null;
    }
  }
  function addToDictionary(word) {
    const cleanWord = word.trim().toLowerCase();
    personalDictionary.add(cleanWord);
    chrome.storage.sync.get(["lingually_dictionary"], (res) => {
      const existing = res.lingually_dictionary || [];
      if (!existing.includes(cleanWord)) {
        chrome.storage.sync.set({ lingually_dictionary: [...existing, cleanWord] });
      }
    });
    checkActiveElement();
  }
  function checkActiveElement() {
    if (!activeElement || !isExtensionEnabled) {
      removeUI();
      return;
    }
    const text = getText(activeElement);
    if (text.length < 3) {
      currentSuggestions = [];
      removeUI();
      return;
    }
    currentSuggestions = runExtensionCheck(text, personalDictionary);
    renderBadge(currentSuggestions.length);
  }
  document.addEventListener(
    "focusin",
    (event) => {
      const target = event.target;
      if (isEditable(target)) {
        activeElement = target;
        checkActiveElement();
      }
    },
    true
  );
  document.addEventListener(
    "input",
    (event) => {
      const target = event.target;
      if (isEditable(target)) {
        activeElement = target;
        if (debounceTimer) clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
          checkActiveElement();
        }, 350);
      }
    },
    true
  );
  document.addEventListener("click", (event) => {
    const target = event.target;
    if (cardElement && !cardElement.contains(target) && badgeElement && !badgeElement.contains(target)) {
      if (cardElement.parentNode) {
        cardElement.parentNode.removeChild(cardElement);
        cardElement = null;
      }
    }
  });
  window.addEventListener("scroll", updateBadgePosition, { passive: true });
  window.addEventListener("resize", updateBadgePosition, { passive: true });
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "LINGUALLY_CONTEXT_MENU_ACTION") {
      if (activeElement && msg.text) {
      }
    }
  });
})();
