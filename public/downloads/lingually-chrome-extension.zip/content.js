"use strict";
(() => {
  // apps/chrome-extension/src/shared-checker.ts
  var DETERMINISTIC_TYPOS = {
    teh: { replacement: "the", explanation: "Corrects typographical inversion." },
    recieve: { replacement: "receive", explanation: "Remember 'i' before 'e' except after 'c'." },
    seperate: { replacement: "separate", explanation: "Correct spelling contains 'para'." },
    definately: { replacement: "definitely", explanation: "Derived from 'finite'." },
    occured: { replacement: "occurred", explanation: "Double 'r' in occurred." },
    untill: { replacement: "until", explanation: "Until has a single 'l'." },
    truely: { replacement: "truly", explanation: "Drop the 'e' in truly." },
    wierd: { replacement: "weird", explanation: "Exception to the 'i before e' rule." },
    acheive: { replacement: "achieve", explanation: "'i' before 'e' in achieve." },
    goverment: { replacement: "government", explanation: "Includes 'n' from govern." },
    tommorrow: { replacement: "tomorrow", explanation: "One 'm', double 'r'." },
    alot: { replacement: "a lot", explanation: "'A lot' is two separate words." },
    noone: { replacement: "no one", explanation: "'No one' is written as two separate words." },
    beleive: { replacement: "believe", explanation: "'i' before 'e' in believe." },
    calender: { replacement: "calendar", explanation: "Spelled with 'ar' at the end." },
    accomodate: { replacement: "accommodate", explanation: "Double 'c' and double 'm'." },
    neccessary: { replacement: "necessary", explanation: "One 'c', double 's'." },
    embarass: { replacement: "embarrass", explanation: "Double 'r' and double 's'." },
    wether: { replacement: "whether", explanation: "Use 'whether' for alternatives or 'weather' for climate." },
    witch: { replacement: "which", explanation: "Use 'which' for choices/clauses." },
    thier: { replacement: "their", explanation: "'e' before 'i' in their." },
    grammer: { replacement: "grammar", explanation: "Spelled with 'ar' at the end." },
    begining: { replacement: "beginning", explanation: "Double 'n' in beginning." },
    realy: { replacement: "really", explanation: "Double 'l' in really." },
    mispell: { replacement: "misspell", explanation: "Double 's' in misspell." },
    suprise: { replacement: "surprise", explanation: "Contains 'r' in the first syllable." },
    succesful: { replacement: "successful", explanation: "Double 'c' and double 's'." },
    publically: { replacement: "publicly", explanation: "Standard spelling is 'publicly'." },
    noticable: { replacement: "noticeable", explanation: "Retain the 'e' in noticeable." },
    independant: { replacement: "independent", explanation: "Ends in 'ent'." },
    gaurantee: { replacement: "guarantee", explanation: "'u' before 'a' in guarantee." },
    foriegn: { replacement: "foreign", explanation: "'e' before 'i' in foreign." },
    enviroment: { replacement: "environment", explanation: "Includes 'n' in iron." },
    dissapear: { replacement: "disappear", explanation: "One 's', double 'p'." },
    definate: { replacement: "definite", explanation: "Ends with 'ite'." },
    collegue: { replacement: "colleague", explanation: "Spelled 'colleague'." },
    catagory: { replacement: "category", explanation: "Spelled with 'e' in category." },
    alright: { replacement: "all right", explanation: "'All right' is preferred in formal writing." },
    basicly: { replacement: "basically", explanation: "Spelled 'basically'." },
    buisness: { replacement: "business", explanation: "'u' before 'i' in business." },
    concious: { replacement: "conscious", explanation: "Contains 'sc' in conscious." },
    dilema: { replacement: "dilemma", explanation: "Double 'm' in dilemma." },
    existance: { replacement: "existence", explanation: "Ends in 'ence'." },
    fascinating: { replacement: "fascinating", explanation: "Spelled with 'sc'." },
    greatful: { replacement: "grateful", explanation: "Spelled 'grateful' (not great)." },
    happend: { replacement: "happened", explanation: "Double 'p' in happened." },
    harrass: { replacement: "harass", explanation: "One 'r', double 's'." },
    humourous: { replacement: "humorous", explanation: "Drop 'u' in humorous." },
    immediatly: { replacement: "immediately", explanation: "Retain 'e' before 'ly'." },
    incidently: { replacement: "incidentally", explanation: "Contains 'al' before 'ly'." },
    interupt: { replacement: "interrupt", explanation: "Double 'r' in interrupt." },
    knowlege: { replacement: "knowledge", explanation: "Contains 'd' in knowledge." },
    liason: { replacement: "liaison", explanation: "Double 'i' in liaison." },
    millenium: { replacement: "millennium", explanation: "Double 'l' and double 'n'." },
    mischevious: { replacement: "mischievous", explanation: "Three syllables: mis-chie-vous." },
    paralell: { replacement: "parallel", explanation: "Double 'l' only in the middle." },
    posession: { replacement: "possession", explanation: "Double 's' twice in possession." },
    priviledge: { replacement: "privilege", explanation: "No 'd' in privilege." },
    pronounciation: { replacement: "pronunciation", explanation: "Spelled 'pronunciation' without 'o'." },
    questionaire: { replacement: "questionnaire", explanation: "Double 'n' in questionnaire." },
    recommand: { replacement: "recommend", explanation: "Spelled with 'e' in recommend." },
    refered: { replacement: "referred", explanation: "Double 'r' in referred." },
    relavant: { replacement: "relevant", explanation: "Spelled 'relevant'." },
    rythm: { replacement: "rhythm", explanation: "Contains 'h' after 'r' and 't'." },
    sieze: { replacement: "seize", explanation: "'e' before 'i' in seize." },
    succede: { replacement: "succeed", explanation: "Double 'e' in succeed." },
    tendancy: { replacement: "tendency", explanation: "Ends with 'ency'." },
    threshhold: { replacement: "threshold", explanation: "Single 'h' in threshold." },
    unfortunatly: { replacement: "unfortunately", explanation: "Retain 'e' in unfortunately." },
    vaccum: { replacement: "vacuum", explanation: "Single 'c', double 'u'." },
    visable: { replacement: "visible", explanation: "Spelled with 'i' in visible." },
    wierdly: { replacement: "weirdly", explanation: "Spelled 'weirdly'." },
    waws: { replacement: "was", explanation: "Correct spelling is 'was'." },
    thiinking: { replacement: "thinking", explanation: "Remove redundant 'i' in thinking." },
    thiis: { replacement: "this", explanation: "Single 'i' in this." },
    iis: { replacement: "is", explanation: "Single 'i' in is." },
    iit: { replacement: "it", explanation: "Single 'i' in it." },
    clrly: { replacement: "clearly", explanation: "Spelled 'clearly'." },
    allso: { replacement: "also", explanation: "Single 'l' in also." },
    buton: { replacement: "button", explanation: "Double 't' in button." },
    vry: { replacement: "very", explanation: "Spelled 'very'." },
    ky: { replacement: "key", explanation: "Spelled 'key'." },
    fiix: { replacement: "fix", explanation: "Single 'i' in fix." },
    instade: { replacement: "instead", explanation: "Spelled 'instead'." },
    desapears: { replacement: "disappears", explanation: "Spelled 'disappears'." },
    alway: { replacement: "always", explanation: "Spelled 'always'." },
    allways: { replacement: "always", explanation: "Single 'l' in always." },
    remian: { replacement: "remain", explanation: "Spelled 'remain'." },
    remians: { replacement: "remains", explanation: "Spelled 'remains'." },
    shud: { replacement: "should", explanation: "Spelled 'should'." },
    cud: { replacement: "could", explanation: "Spelled 'could'." },
    wud: { replacement: "would", explanation: "Spelled 'would'." },
    pls: { replacement: "please", explanation: "Spelled 'please'." },
    thx: { replacement: "thanks", explanation: "Spelled 'thanks'." }
  };
  var DETERMINISTIC_CONFUSIONS = [
    { pattern: /\bcould of\b/gi, replacement: "could have", explanation: "Use 'could have' instead of 'could of'." },
    { pattern: /\bshould of\b/gi, replacement: "should have", explanation: "Use 'should have' instead of 'should of'." },
    { pattern: /\bwould of\b/gi, replacement: "would have", explanation: "Use 'would have' instead of 'would of'." },
    { pattern: /\bmight of\b/gi, replacement: "might have", explanation: "Use 'might have' instead of 'might of'." },
    { pattern: /\bsuppose to\b/gi, replacement: "supposed to", explanation: "The past participle 'supposed to' is required." },
    { pattern: /\buse to\b/gi, replacement: "used to", explanation: "The idiom is 'used to'." },
    { pattern: /\beach others\b/gi, replacement: "each other's", explanation: "Add an apostrophe for possessive 'each other's'." },
    { pattern: /\bone anothers\b/gi, replacement: "one another's", explanation: "Add an apostrophe for possessive 'one another's'." },
    { pattern: /\bthere own\b/gi, replacement: "their own", explanation: "Use possessive 'their' with own." },
    { pattern: /\byour welcome\b/gi, replacement: "you're welcome", explanation: "Use 'you're' (you are welcome)." },
    { pattern: /\bits a\b/gi, replacement: "it's a", explanation: "Contraction 'it's' (it is a) is required." },
    { pattern: /\btheir is\b/gi, replacement: "there is", explanation: "Use 'there is' for existence." },
    { pattern: /\btheir are\b/gi, replacement: "there are", explanation: "Use 'there are' for existence." },
    { pattern: /\blose to much\b/gi, replacement: "lose too much", explanation: "'Too' means excessively." },
    { pattern: /\bto much\b/gi, replacement: "too much", explanation: "Use 'too' to mean an excessive amount." },
    { pattern: /\bto many\b/gi, replacement: "too many", explanation: "Use 'too' for excessive count." }
  ];
  var DETERMINISTIC_CLARITY = [
    { pattern: /\bin order to\b/gi, replacement: "to", explanation: "Simplify 'in order to' to simply 'to'." },
    { pattern: /\bat this point in time\b/gi, replacement: "now", explanation: "Concise alternative: 'now' or 'currently'." },
    { pattern: /\bdue to the fact that\b/gi, replacement: "because", explanation: "Simplify wordy phrase to 'because'." },
    { pattern: /\bhas the ability to\b/gi, replacement: "can", explanation: "Direct verb 'can' improves conciseness." },
    { pattern: /\bfor the purpose of\b/gi, replacement: "for", explanation: "Streamline 'for the purpose of' to 'for'." },
    { pattern: /\bin the event that\b/gi, replacement: "if", explanation: "Use 'if' for immediate clarity." },
    { pattern: /\ba large number of\b/gi, replacement: "many", explanation: "More direct and concise: 'many'." },
    { pattern: /\ba small number of\b/gi, replacement: "few", explanation: "Use 'few' instead of 'a small number of'." },
    { pattern: /\butilize\b/gi, replacement: "use", explanation: "'Use' is more direct than 'utilize'." },
    { pattern: /\butilizes\b/gi, replacement: "uses", explanation: "'Uses' is clearer than 'utilizes'." },
    { pattern: /\butilized\b/gi, replacement: "used", explanation: "'Used' is more natural." },
    { pattern: /\bat the present time\b/gi, replacement: "currently", explanation: "Use 'currently' or 'now'." },
    { pattern: /\bin spite of the fact that\b/gi, replacement: "although", explanation: "Simplify to 'although'." },
    { pattern: /\bwith the exception of\b/gi, replacement: "except", explanation: "Use 'except'." },
    { pattern: /\btake into consideration\b/gi, replacement: "consider", explanation: "Direct verb 'consider'." },
    { pattern: /\bmake a decision\b/gi, replacement: "decide", explanation: "Use the strong verb 'decide'." }
  ];
  var DETERMINISTIC_ENGAGEMENT = [
    { pattern: /\bvery good\b/gi, replacement: "exceptional", explanation: "Vivid alternative: 'exceptional' or 'superb'." },
    { pattern: /\bvery bad\b/gi, replacement: "terrible", explanation: "Expressive alternative: 'terrible' or 'dreadful'." },
    { pattern: /\bvery big\b/gi, replacement: "massive", explanation: "More vivid adjective: 'massive' or 'vast'." },
    { pattern: /\bvery small\b/gi, replacement: "tiny", explanation: "Dynamic alternative: 'tiny' or 'minuscule'." },
    { pattern: /\bvery important\b/gi, replacement: "crucial", explanation: "Stronger emphasis: 'crucial' or 'essential'." },
    { pattern: /\bvery happy\b/gi, replacement: "thrilled", explanation: "Evocative alternative: 'thrilled' or 'delighted'." },
    { pattern: /\bvery sad\b/gi, replacement: "devastated", explanation: "Expressive alternative: 'devastated'." },
    { pattern: /\bvery hard\b/gi, replacement: "challenging", explanation: "Refined adjective: 'demanding' or 'challenging'." }
  ];
  var DETERMINISTIC_DELIVERY = [
    { pattern: /\bI think that maybe\b/gi, replacement: "Perhaps", explanation: "Removes weak hedging for a more confident tone." },
    { pattern: /\bjust wondering if\b/gi, replacement: "could you", explanation: "Direct phrasing sounds more professional." },
    { pattern: /\bsorry to bother you,?\b/gi, replacement: "", explanation: "Polite but unnecessary hedging." },
    { pattern: /\byou should probably consider\b/gi, replacement: "we recommend", explanation: "Decisive phrasing sounds authoritative." }
  ];
  var COMMON_VOCABULARY = /* @__PURE__ */ new Set([
    "the",
    "be",
    "to",
    "of",
    "and",
    "a",
    "in",
    "that",
    "have",
    "i",
    "it",
    "for",
    "not",
    "on",
    "with",
    "he",
    "as",
    "you",
    "do",
    "at",
    "this",
    "but",
    "his",
    "by",
    "from",
    "they",
    "we",
    "say",
    "her",
    "she",
    "or",
    "an",
    "will",
    "my",
    "one",
    "all",
    "would",
    "there",
    "their",
    "what",
    "so",
    "up",
    "out",
    "if",
    "about",
    "who",
    "get",
    "which",
    "go",
    "me",
    "when",
    "make",
    "can",
    "like",
    "time",
    "no",
    "just",
    "him",
    "know",
    "take",
    "people",
    "into",
    "year",
    "your",
    "good",
    "some",
    "could",
    "them",
    "see",
    "other",
    "than",
    "then",
    "now",
    "look",
    "only",
    "come",
    "its",
    "over",
    "think",
    "also",
    "back",
    "after",
    "use",
    "two",
    "how",
    "our",
    "work",
    "first",
    "well",
    "way",
    "even",
    "new",
    "want",
    "because",
    "any",
    "these",
    "give",
    "day",
    "most",
    "us",
    "is",
    "are",
    "was",
    "were",
    "has",
    "had",
    "been",
    "am",
    "ready",
    "here",
    "help",
    "please",
    "write",
    "chat",
    "send",
    "message",
    "text",
    "search",
    "press",
    "open",
    "close",
    "view",
    "edit",
    "save",
    "delete",
    "create",
    "start",
    "stop",
    "check",
    "review",
    "find",
    "read",
    "run",
    "file",
    "page",
    "app",
    "web",
    "tool",
    "user",
    "input",
    "mode",
    "screen",
    "code",
    "data",
    "test",
    "issue",
    "error",
    "word",
    "line",
    "paragraph",
    "sentence",
    "grammar",
    "spell",
    "correct",
    "fix",
    "tone",
    "formal",
    "clear",
    "fast",
    "free",
    "key",
    "setting",
    "privacy",
    "model",
    "ai",
    "assistant",
    "lingually",
    "chrome",
    "system",
    "click",
    "select",
    "type",
    "today",
    "tomorrow",
    "yesterday",
    "always",
    "never",
    "often",
    "sometimes",
    "very",
    "much",
    "many",
    "few",
    "little",
    "big",
    "small",
    "high",
    "low",
    "long",
    "short",
    "right",
    "wrong",
    "true",
    "false",
    "yes",
    "sure",
    "fine",
    "great",
    "best",
    "better",
    "worse",
    "worst",
    "more",
    "less",
    "least",
    "again",
    "already",
    "still",
    "yet",
    "maybe",
    "perhaps",
    "actually",
    "really",
    "simply",
    "quite",
    "rather",
    "pretty",
    "almost",
    "enough",
    "too",
    "both",
    "either",
    "neither",
    "each",
    "every",
    "own",
    "same",
    "such",
    "why",
    "where",
    "how",
    "while",
    "since",
    "until",
    "before",
    "during",
    "through",
    "across",
    "under",
    "above",
    "between",
    "among",
    "against",
    "without",
    "within",
    "around",
    "behind",
    "beyond",
    "upon",
    "towards",
    "near",
    "off",
    "down",
    "left",
    "front",
    "side",
    "center",
    "hello",
    "hi",
    "hey",
    "thanks",
    "thank",
    "welcome",
    "sorry",
    "excuse",
    "pardon",
    "bye",
    "question",
    "answer",
    "reason",
    "problem",
    "solution",
    "result",
    "action",
    "change",
    "point",
    "thing",
    "place",
    "part",
    "number",
    "group",
    "fact",
    "idea",
    "story",
    "life",
    "world",
    "hand",
    "eye",
    "head",
    "face",
    "voice",
    "sound",
    "mind",
    "heart",
    "body",
    "name",
    "call",
    "keep",
    "let",
    "begin",
    "seem",
    "help",
    "talk",
    "turn",
    "start",
    "show",
    "hear",
    "play",
    "move",
    "live",
    "believe",
    "hold",
    "bring",
    "happen",
    "must",
    "write",
    "provide",
    "sit",
    "stand",
    "lose",
    "pay",
    "meet",
    "include",
    "continue",
    "set",
    "learn",
    "lead",
    "understand",
    "watch",
    "follow",
    "stop",
    "allow",
    "add",
    "spend",
    "grow",
    "open",
    "walk",
    "win",
    "offer",
    "remember",
    "love",
    "consider",
    "appear",
    "buy",
    "wait",
    "serve",
    "die",
    "send",
    "expect",
    "build",
    "stay",
    "fall",
    "cut",
    "reach",
    "kill",
    "remain",
    "suggest",
    "raise",
    "pass",
    "sell",
    "require",
    "report",
    "decide",
    "pull",
    "thinking",
    "thought",
    "going",
    "night",
    "tonight",
    "evening",
    "weekend",
    "outside",
    "dinner",
    "lunch",
    "breakfast",
    "food",
    "movie",
    "fun",
    "friend",
    "friends",
    "family",
    "house",
    "home",
    "car",
    "drive",
    "sleep",
    "felt",
    "feel",
    "wants",
    "wanted",
    "consequently",
    "essence",
    "agenda",
    "furthermore",
    "moreover",
    "therefore",
    "accordingly",
    "considering",
    "heading",
    "venturing",
    "contemplating",
    "endeavoring",
    "assistance",
    "specifically",
    "regarding",
    "deliberate",
    "perspective",
    "performance",
    "recommendation",
    "structure",
    "development",
    "workbench",
    "interface",
    "platform",
    "extension",
    "application",
    "browser",
    "document",
    "paragraph",
    "sentence",
    "selection",
    "dictionary",
    "paraphrase",
    "clarity",
    "engagement",
    "delivery",
    "correctness",
    "accuracy",
    "context",
    "definition",
    "information",
    "experience",
    "opportunity",
    "knowledge",
    "strategy",
    "solution",
    "possible",
    "important",
    "necessary",
    "problem",
    "difficult",
    "simple",
    "example",
    "already",
    "general",
    "particular",
    "usually",
    "certain",
    "different",
    "similar",
    "available",
    "several",
    "together",
    "against",
    "without",
    "within",
    "between",
    "toward",
    "course",
    "matter",
    "perhaps",
    "however",
    "although",
    "except"
  ]);
  var COMMON_NAMES = /* @__PURE__ */ new Set([
    // Names
    "john",
    "david",
    "sarah",
    "mary",
    "michael",
    "james",
    "robert",
    "william",
    "thomas",
    "charles",
    "daniel",
    "matthew",
    "anthony",
    "mark",
    "donald",
    "steven",
    "paul",
    "andrew",
    "joshua",
    "kenneth",
    "kevin",
    "brian",
    "george",
    "edward",
    "ronald",
    "timothy",
    "jason",
    "jeffrey",
    "ryan",
    "jacob",
    "gary",
    "nicholas",
    "eric",
    "jonathan",
    "stephen",
    "larry",
    "justin",
    "scott",
    "brandon",
    "benjamin",
    "samuel",
    "gregory",
    "alexander",
    "patrick",
    "frank",
    "raymond",
    "jack",
    "dennis",
    "jerry",
    "tyler",
    "aaron",
    "jose",
    "adam",
    "nathan",
    "henry",
    "douglas",
    "zachary",
    "peter",
    "kyle",
    "walter",
    "ethan",
    "jeremy",
    "harold",
    "keith",
    "christian",
    "roger",
    "noah",
    "gerald",
    "carl",
    "terry",
    "sean",
    "arthur",
    "austin",
    "lawrence",
    "jesse",
    "dylan",
    "bryan",
    "joe",
    "jordan",
    "billy",
    "bruce",
    "albert",
    "gabriel",
    "logan",
    "alan",
    "juan",
    "wayne",
    "roy",
    "ralph",
    "randy",
    "eugene",
    "vincent",
    "russell",
    "louis",
    "philip",
    "bobby",
    "johnny",
    "bradley",
    "binyam",
    "emma",
    "olivia",
    "ava",
    "isabella",
    "sophia",
    "mia",
    "charlotte",
    "amelia",
    "harper",
    "evelyn",
    "abigail",
    "emily",
    "elizabeth",
    "mila",
    "ella",
    "avery",
    "sofia",
    "camila",
    "aria",
    "scarlett",
    "victoria",
    "madison",
    "luna",
    "grace",
    "chloe",
    "penelope",
    "layla",
    "riley",
    "zoey",
    "nora",
    "lily",
    "eleanor",
    "hannah",
    "lillian",
    "addison",
    "aubrey",
    "ellie",
    "stella",
    "natalie",
    "zoe",
    "leah",
    "hazel",
    "violet",
    "aurora",
    "savannah",
    "audrey",
    "brooklyn",
    "bella",
    "claire",
    "skylar",
    "lucy",
    "paisley",
    "everly",
    "anna",
    "caroline",
    "nova",
    "genesis",
    "emilia",
    "kennedy",
    "samantha",
    "maya",
    "willow",
    "kinsley",
    "naomi",
    "aaliyah",
    "elena",
    "ariana",
    "allison",
    "gabriella",
    "alice",
    "madelyn",
    "cora",
    "ruby",
    "eva",
    "serenity",
    "autumn",
    "adeline",
    "hailey",
    "gianna",
    "valentine",
    // Brands / Organizations / Platforms / Places
    "google",
    "apple",
    "microsoft",
    "amazon",
    "meta",
    "twitter",
    "facebook",
    "instagram",
    "quillbot",
    "grammarly",
    "openai",
    "github",
    "gitlab",
    "youtube",
    "linkedin",
    "slack",
    "discord",
    "reddit",
    "tauri",
    "vercel",
    "nextjs",
    "react",
    "typescript",
    "javascript",
    "python",
    "node",
    "macos",
    "windows",
    "linux",
    "ios",
    "android",
    "chrome",
    "firefox",
    "safari",
    "edge",
    "london",
    "paris",
    "tokyo",
    "berlin",
    "york",
    "california",
    "america",
    "europe",
    "asia",
    "africa"
  ]);
  function levenshteinDistance(a, b) {
    const m = a.length;
    const n = b.length;
    const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        if (a[i - 1] === b[j - 1]) {
          dp[i][j] = dp[i - 1][j - 1];
        } else {
          dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
        }
      }
    }
    return dp[m][n];
  }
  function findClosestWord(target) {
    let closest = null;
    let minDistance = 3;
    for (const word of COMMON_VOCABULARY) {
      if (Math.abs(word.length - target.length) > 2) continue;
      const dist = levenshteinDistance(target, word);
      if (dist < minDistance) {
        minDistance = dist;
        closest = word;
        if (dist === 1) break;
      }
    }
    return closest;
  }
  var VALID_SHORT_WORDS = /* @__PURE__ */ new Set([
    "a",
    "i",
    "am",
    "an",
    "as",
    "at",
    "be",
    "by",
    "do",
    "go",
    "he",
    "hi",
    "if",
    "in",
    "is",
    "it",
    "me",
    "my",
    "no",
    "of",
    "ok",
    "on",
    "or",
    "so",
    "to",
    "up",
    "us",
    "we"
  ]);
  function isLikelyGibberishOrMisspelling(word, isProperNoun = false) {
    const lower = word.toLowerCase();
    if (COMMON_VOCABULARY.has(lower) || DETERMINISTIC_TYPOS[lower] || COMMON_NAMES.has(lower)) return false;
    if (isProperNoun || /[a-z][A-Z]/.test(word)) return false;
    if (lower.length <= 2) {
      return !VALID_SHORT_WORDS.has(lower);
    }
    const rootS = lower.endsWith("s") ? lower.slice(0, -1) : "";
    const rootEd = lower.endsWith("ed") ? lower.slice(0, -2) : "";
    const rootIng = lower.endsWith("ing") ? lower.slice(0, -3) : "";
    const rootLy = lower.endsWith("ly") ? lower.slice(0, -2) : "";
    if (rootS && COMMON_VOCABULARY.has(rootS) || rootEd && COMMON_VOCABULARY.has(rootEd) || rootIng && COMMON_VOCABULARY.has(rootIng) || rootLy && COMMON_VOCABULARY.has(rootLy)) {
      return false;
    }
    if (/([a-zA-Z])\1\1/.test(lower)) return true;
    if (/[b-df-hj-np-tv-z]{5,}/.test(lower)) return true;
    if (lower.length >= 4 && !/[aeiouy]/.test(lower)) return true;
    if (/^(hh|vv|jj|xx|ww)/.test(lower) && !["which", "who", "whom", "whose", "where", "when", "why", "what", "white", "while", "wheel"].includes(lower)) return true;
    if (/(hgg|ggu|zzk|xkz|qq|q[^u]|ii|uu)/.test(lower) && !["skiing", "radii", "pompeii", "hawaii"].includes(lower)) return true;
    return false;
  }
  function runExtensionCheck(text, personalDictionary2 = /* @__PURE__ */ new Set()) {
    const suggestions = [];
    let idCounter = 1;
    let match = null;
    if (!text || text.trim().length === 0) return suggestions;
    const sentenceCapRegex = /(^|[.!?]\s+)([a-z])/g;
    while ((match = sentenceCapRegex.exec(text)) !== null) {
      const prefix = match[1];
      const letter = match[2];
      const offset = match.index + prefix.length;
      suggestions.push({
        id: `ext_cap_${idCounter++}`,
        category: "correctness",
        originalText: letter,
        replacementText: letter.toUpperCase(),
        explanation: "Capitalize the first letter of a sentence.",
        offset,
        length: 1
      });
    }
    const multiSpaceRegex = /[^\S\r\n]{2,}/g;
    while ((match = multiSpaceRegex.exec(text)) !== null) {
      suggestions.push({
        id: `ext_space_${idCounter++}`,
        category: "clarity",
        originalText: match[0],
        replacementText: " ",
        explanation: "Remove redundant whitespace.",
        offset: match.index,
        length: match[0].length
      });
    }
    const danglingRegex = /\b(a|an|the)\s+([a-zA-Z]+)\s+(but|and|or|so|yet|because|if)\b/gi;
    while ((match = danglingRegex.exec(text)) !== null) {
      const article = match[1];
      const adj = match[2];
      const conj = match[3];
      if (["new", "old", "big", "small", "good", "bad", "great", "different"].includes(adj.toLowerCase())) {
        suggestions.push({
          id: `ext_dangle_${idCounter++}`,
          category: "clarity",
          originalText: match[0],
          replacementText: `${article} ${adj} one, ${conj}`,
          explanation: `Incomplete phrase: '${article} ${adj}' requires a noun before '${conj}'.`,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    if (/^(can|could|would|will|do|did|does|is|are|was|were|what|where|when|why|how)\b/i.test(text.trim()) && !/[.?!]$/.test(text.trim())) {
      const trimmed = text.trim();
      const lastCharIdx = text.lastIndexOf(trimmed.slice(-1));
      suggestions.push({
        id: `ext_qmark_${idCounter++}`,
        category: "correctness",
        originalText: text.slice(lastCharIdx),
        replacementText: `${trimmed.slice(-1)}?`,
        explanation: "Add a question mark at the end of a question.",
        offset: lastCharIdx,
        length: 1
      });
    }
    const standaloneIRegex = /(^|[\s(])i([\s),.?!]|$)/g;
    while ((match = standaloneIRegex.exec(text)) !== null) {
      const prefix = match[1];
      const offset = match.index + prefix.length;
      if (!suggestions.some((s) => s.offset === offset)) {
        suggestions.push({
          id: `ext_i_${idCounter++}`,
          category: "correctness",
          originalText: "i",
          replacementText: "I",
          explanation: "Capitalize the standalone personal pronoun 'I'.",
          offset,
          length: 1
        });
      }
    }
    const repeatedRegex = /\b([a-zA-Z]+)\s+\1\b/gi;
    while ((match = repeatedRegex.exec(text)) !== null) {
      const rawWord = match[1];
      suggestions.push({
        id: `ext_rep_${idCounter++}`,
        category: "correctness",
        originalText: match[0],
        replacementText: rawWord,
        explanation: `Repeated word '${rawWord}'. Remove the duplicate.`,
        offset: match.index,
        length: match[0].length
      });
    }
    const linkSpans = [];
    const linkRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}|\b[a-zA-Z0-9-]+\.(com|org|net|edu|gov|io|app|dev|co|ai|uk|de|fr|ca|me)(\/[^\s]*)?|\/[a-zA-Z0-9_\-./]+)/gi;
    let lMatch = null;
    while ((lMatch = linkRegex.exec(text)) !== null) {
      linkSpans.push({ start: lMatch.index, end: lMatch.index + lMatch[0].length });
    }
    const wordRegex = /\b[a-zA-Z]+\b/g;
    while ((match = wordRegex.exec(text)) !== null) {
      const rawWord = match[0];
      const lower = rawWord.toLowerCase();
      if (personalDictionary2.has(lower)) continue;
      if (linkSpans.some((span) => match.index >= span.start && match.index < span.end)) {
        continue;
      }
      const textBefore = text.slice(0, match.index).trim();
      const isSentenceStart = textBefore.length === 0 || /[.!?]\s*$/.test(textBefore) || /\n\s*$/.test(textBefore);
      const isCap = rawWord[0] === rawWord[0].toUpperCase() && rawWord[0] !== rawWord[0].toLowerCase();
      const isCamelCase = /[a-z][A-Z]/.test(rawWord);
      const isKnownName = COMMON_NAMES.has(lower);
      const isProperNoun = isCamelCase || isKnownName || isCap && !isSentenceStart;
      if (DETERMINISTIC_TYPOS[lower]) {
        const entry = DETERMINISTIC_TYPOS[lower];
        const isCapitalized = isCap;
        const replacement = isCapitalized ? entry.replacement.charAt(0).toUpperCase() + entry.replacement.slice(1) : entry.replacement;
        suggestions.push({
          id: `ext_typo_${idCounter++}`,
          category: "correctness",
          originalText: rawWord,
          replacementText: replacement,
          explanation: entry.explanation,
          offset: match.index,
          length: rawWord.length
        });
        continue;
      }
      if (isProperNoun) {
        continue;
      }
      if (/ii/.test(lower) && !["skiing", "radii", "pompeii", "hawaii"].includes(lower)) {
        const singleI = lower.replace(/ii/g, "i");
        if (COMMON_VOCABULARY.has(singleI) || VALID_SHORT_WORDS.has(singleI) || DETERMINISTIC_TYPOS[singleI]) {
          const isCapitalized = isCap;
          const replacement = isCapitalized ? singleI.charAt(0).toUpperCase() + singleI.slice(1) : singleI;
          suggestions.push({
            id: `ext_double_i_${idCounter++}`,
            category: "correctness",
            originalText: rawWord,
            replacementText: replacement,
            explanation: `Remove redundant 'i' in '${rawWord}'.`,
            offset: match.index,
            length: rawWord.length
          });
          continue;
        }
      }
      if (isLikelyGibberishOrMisspelling(rawWord, isProperNoun)) {
        const closest = findClosestWord(lower);
        const rep = closest ? isCap ? closest.charAt(0).toUpperCase() + closest.slice(1) : closest : "";
        suggestions.push({
          id: `ext_gib_${idCounter++}`,
          category: "correctness",
          originalText: rawWord,
          replacementText: rep,
          explanation: closest ? `Possible misspelling. Did you mean '${rep}'?` : `Unrecognized word '${rawWord}'. Remove it or add to dictionary if correct.`,
          offset: match.index,
          length: rawWord.length
        });
      }
    }
    for (const item of DETERMINISTIC_CONFUSIONS) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_conf_${idCounter++}`,
          category: "correctness",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_CLARITY) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_clarity_${idCounter++}`,
          category: "clarity",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_ENGAGEMENT) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_eng_${idCounter++}`,
          category: "engagement",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_DELIVERY) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_del_${idCounter++}`,
          category: "delivery",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    const sentenceMatches = text.match(/[^.!?\n]+[.!?]?/g) || [text];
    let searchOffset = 0;
    for (const rawSentence of sentenceMatches) {
      const sStart = text.indexOf(rawSentence, searchOffset);
      if (sStart === -1) continue;
      searchOffset = sStart + rawSentence.length;
      const trimmed = rawSentence.trim();
      const words = trimmed.split(/\s+/).filter(Boolean);
      if (words.length >= 3) {
        const sentenceIssues = suggestions.filter(
          (item) => item.offset >= sStart && item.offset < sStart + rawSentence.length
        );
        const isFragmented = /\b(a|an|the)\s+[a-zA-Z]+\s+(but|and|or|so|yet)\b/i.test(trimmed) || /\bI\s+[a-zA-Z]+\s+I\b/i.test(trimmed) || /\b(can|could|would)\s+you\s+chat\b/i.test(trimmed) || /\b(waws|thiinking|thiis|iis|iit|clrly|allso|buton|vry|ky|fiix|instade|desapears)\b/i.test(trimmed) || /\bthinking to go\b/i.test(trimmed) || /\bgo out this\b/i.test(trimmed) || /\bnam\b/i.test(trimmed);
        if (isFragmented || sentenceIssues.length >= 2) {
          const paraphrased = paraphraseText(trimmed, "standard", true);
          if (paraphrased.toLowerCase() !== trimmed.toLowerCase() && !paraphrased.toLowerCase().startsWith(trimmed.toLowerCase())) {
            const trimmedStart = sStart + rawSentence.indexOf(trimmed);
            suggestions.push({
              id: `ext_rephrase_${idCounter++}`,
              category: "clarity",
              // Blue wavy underline
              originalText: trimmed,
              replacementText: paraphrased,
              explanation: "Sentence structure is awkward or incomplete. Click to rephrase into clear, natural English.",
              offset: trimmedStart,
              length: trimmed.length
            });
          }
        }
      }
    }
    return suggestions.sort((a, b) => a.offset - b.offset);
  }
  function paraphraseText(text, mode = "standard", forChecker = false) {
    if (!text || text.trim().length === 0) return text;
    let result = text.trim();
    result = result.replace(/\bcheck spelling\b/gi, "").trim();
    result = result.replace(/\s{2,}/g, " ");
    result = result.replace(/(^|[\s(])i([\s),.?!]|$)/g, "$1I$2");
    for (const [typo, fix] of Object.entries(DETERMINISTIC_TYPOS)) {
      const rx = new RegExp(`\\b${typo}\\b`, "gi");
      if (rx.test(result)) {
        result = result.replace(rx, fix.replacement);
      }
    }
    result = result.replace(/\b([b-df-hj-np-tv-z]{5,}|[a-z]*([a-z])\2{3,}[a-z]*)\b/gi, "").trim();
    result = result.replace(/\s{2,}/g, " ");
    result = result.replace(/\bthinking of going out this$/gi, "thinking of going out this evening");
    result = result.replace(/\bgoing out this$/gi, "going out this evening");
    result = result.replace(/\bout this$/gi, "out this evening");
    result = result.replace(/\bthinking to go\b/gi, "thinking of going");
    result = result.replace(/\bcan you chat a new\b/gi, "can you start a new chat");
    result = result.replace(/\bI nam\b/gi, "I am");
    result = result.replace(/\bI side\b/gi, "on my side");
    result = result.replace(/\ba new but\b/gi, "a new one, but");
    result = result.replace(/\s{2,}/g, " ").trim();
    if (mode === "formal") {
      result = result.replace(/\bcan't\b/gi, "cannot");
      result = result.replace(/\bdon't\b/gi, "do not");
      result = result.replace(/\bwon't\b/gi, "will not");
      result = result.replace(/\bit's\b/gi, "it is");
      result = result.replace(/\bthat's\b/gi, "that is");
      result = result.replace(/\bthere's\b/gi, "there is");
      result = result.replace(/\bwe're\b/gi, "we are");
      result = result.replace(/\byou're\b/gi, "you are");
      result = result.replace(/\bi'm\b/gi, "I am");
      result = result.replace(/\bi've\b/gi, "I have");
      result = result.replace(/\bi'll\b/gi, "I will");
      result = result.replace(/\bdidn't\b/gi, "did not");
      result = result.replace(/\bcouldn't\b/gi, "could not");
      result = result.replace(/\bshouldn't\b/gi, "should not");
      result = result.replace(/\bwouldn't\b/gi, "would not");
      result = result.replace(/^So I was thinking of going out\b/gi, "Consequently, I am contemplating venturing out");
      result = result.replace(/^So I was thinking of\b/gi, "Consequently, I have been contemplating");
      result = result.replace(/^So I was\b/gi, "Accordingly, I was");
      result = result.replace(/^So I am\b/gi, "Accordingly, I am");
      result = result.replace(/^So I\b/gi, "Consequently, I");
      result = result.replace(/^So we\b/gi, "Accordingly, we");
      result = result.replace(/^So\b/gi, "Therefore");
      result = result.replace(/\bthinking of going out\b/gi, "contemplating venturing out");
      result = result.replace(/\bthinking of\b/gi, "contemplating");
      result = result.replace(/\bthinking about\b/gi, "considering");
      result = result.replace(/\bgoing out\b/gi, "departing");
      result = result.replace(/\bwant to\b/gi, "intend to");
      result = result.replace(/\bwants to\b/gi, "intends to");
      result = result.replace(/\bneed to\b/gi, "require to");
      result = result.replace(/\bhave to\b/gi, "must");
      result = result.replace(/\btrying to\b/gi, "endeavoring to");
      result = result.replace(/\bask for\b/gi, "request");
      result = result.replace(/\bask\b/gi, "inquire");
      result = result.replace(/\bhelp with\b/gi, "provide assistance with");
      result = result.replace(/\bhelp\b/gi, "assist");
      result = result.replace(/\bshow\b/gi, "demonstrate");
      result = result.replace(/\bget\b/gi, "obtain");
      result = result.replace(/\bgive\b/gi, "provide");
      result = result.replace(/\btell\b/gi, "inform");
      result = result.replace(/\bbuy\b/gi, "purchase");
      result = result.replace(/\bstart\b/gi, "commence");
      result = result.replace(/\bfinish\b/gi, "conclude");
      result = result.replace(/\bfix\b/gi, "rectify");
      result = result.replace(/\bmake sure\b/gi, "ensure");
      result = result.replace(/\bcheck\b/gi, "verify");
      result = result.replace(/\btalk about\b/gi, "deliberate upon");
      result = result.replace(/\blook into\b/gi, "investigate");
      result = result.replace(/\bfind out\b/gi, "ascertain");
      result = result.replace(/\bvery good\b/gi, "exemplary");
      result = result.replace(/\bgood\b/gi, "favorable");
      result = result.replace(/\bbad\b/gi, "adverse");
      result = result.replace(/\bbig\b/gi, "substantial");
      result = result.replace(/\bimportant\b/gi, "paramount");
      result = result.replace(/\babout\b/gi, "regarding");
      result = result.replace(/\balso\b/gi, "furthermore");
      result = result.replace(/\bbut\b/gi, "however");
    } else if (mode === "shorten") {
      result = result.replace(/^So I was thinking of going out this evening\b/gi, "I plan to go out tonight");
      result = result.replace(/^So I was thinking of going out\b/gi, "I plan to go out");
      result = result.replace(/^So I was thinking of\b/gi, "I plan to");
      result = result.replace(/^So I\b/gi, "I");
      result = result.replace(/^So\b/gi, "");
      result = result.replace(/\bwas thinking of going out\b/gi, "plan to go out");
      result = result.replace(/\bthinking of going out\b/gi, "going out");
      result = result.replace(/\bwas thinking of\b/gi, "planned to");
      result = result.replace(/\bwould like to\b/gi, "want to");
      result = result.replace(/\bin order to\b/gi, "to");
      result = result.replace(/\bat this point in time\b/gi, "now");
      result = result.replace(/\bdue to the fact that\b/gi, "because");
      result = result.replace(/\bhas the ability to\b/gi, "can");
      result = result.replace(/\bfor the purpose of\b/gi, "for");
      result = result.replace(/\bin the event that\b/gi, "if");
      result = result.replace(/\bwith the exception of\b/gi, "except");
      result = result.replace(/\btake into consideration\b/gi, "consider");
      result = result.replace(/\bmake a decision\b/gi, "decide");
      result = result.replace(/\bis able to\b/gi, "can");
      result = result.replace(/\bthis evening\b/gi, "tonight");
      result = result.replace(/\ba large number of\b/gi, "many");
      result = result.replace(/\ba small number of\b/gi, "few");
      result = result.replace(/\breally\s+/gi, "");
      result = result.replace(/\bvery\s+/gi, "");
      result = result.replace(/\bquite\s+/gi, "");
      result = result.replace(/\bbasically\s+/gi, "");
      result = result.replace(/\bactually\s+/gi, "");
      result = result.replace(/\bliterally\s+/gi, "");
      result = result.replace(/\bjust\s+/gi, "");
      result = result.replace(/\bsomewhat\s+/gi, "");
    } else if (mode === "fluency") {
      result = result.replace(/^So I was thinking of going out\b/gi, "I was thinking about heading out");
      result = result.replace(/^So I was thinking of\b/gi, "I was thinking about");
      result = result.replace(/^So I was\b/gi, "I was honestly");
      result = result.replace(/^So I\b/gi, "I");
      result = result.replace(/\bthinking to go\b/gi, "thinking of going");
      result = result.replace(/\bthinking of going out\b/gi, "thinking about heading out");
      result = result.replace(/\bgoing out this evening\b/gi, "going out tonight");
      result = result.replace(/\bwant to\b/gi, "am looking to");
      result = result.replace(/\bneed to\b/gi, "should probably");
      result = result.replace(/\btalk about\b/gi, "chat about");
      result = result.replace(/\blook into\b/gi, "check out");
      result = result.replace(/\bgive a call\b/gi, "reach out to");
      result = result.replace(/\bat the moment\b/gi, "right now");
      result = result.replace(/\bvery good\b/gi, "really great");
      result = result.replace(/\bvery nice\b/gi, "wonderful");
      result = result.replace(/\bin order to\b/gi, "to");
      result = result.replace(/\bdue to the fact that\b/gi, "since");
      result = result.replace(/\bhas the ability to\b/gi, "can easily");
      result = result.replace(/\butilize\b/gi, "use");
    } else if (mode === "expand") {
      result = result.replace(/^So I was thinking of going out this evening\b/gi, "As a result, I have been actively considering the possibility of going out this evening to spend some time outside and enjoy a change of scenery");
      result = result.replace(/^So I was thinking of going out\b/gi, "As a result, I have been actively considering the possibility of going out to enjoy some fresh air");
      result = result.replace(/^So I was thinking of\b/gi, "As a result, I have been actively considering the possibility of");
      result = result.replace(/^So I\b/gi, "Given the present circumstances, I");
      result = result.replace(/^I want to\b/gi, "I am genuinely keen and eager to");
      result = result.replace(/^We need to\b/gi, "It is of fundamental importance that we take the necessary steps to");
      result = result.replace(/^Can you\b/gi, "Would it be possible for you to kindly");
      result = result.replace(/\bthinking of going out\b/gi, "actively contemplating going out to spend some quality time outside");
      result = result.replace(/\bthinking of\b/gi, "actively considering the possibility of");
      result = result.replace(/\bwant to\b/gi, "have a strong desire to");
      result = result.replace(/\bneed to\b/gi, "find it absolutely essential to");
      result = result.replace(/\btrying to\b/gi, "making a concerted and deliberate effort to");
      result = result.replace(/\bhelp with\b/gi, "provide comprehensive assistance and support with");
      result = result.replace(/\btalk about\b/gi, "thoroughly discuss and examine all aspects of");
      result = result.replace(/\bmake sure\b/gi, "take every appropriate measure to guarantee");
      result = result.replace(/\bgood\b/gi, "thorough, well-crafted, and highly beneficial");
      result = result.replace(/\bbad\b/gi, "substantially problematic and counterproductive");
      result = result.replace(/\bbig\b/gi, "remarkably extensive and significant");
      result = result.replace(/\bimportant\b/gi, "essential to achieving our intended objectives");
      result = result.replace(/\bhard\b/gi, "demanding and intricately challenging");
      result = result.replace(/\beasy\b/gi, "accessible, smooth, and straightforward to execute");
      result = result.replace(/\bthis evening\b/gi, "during the course of this evening");
      result = result.replace(/\btoday\b/gi, "throughout the day today");
      result = result.replace(/\btomorrow\b/gi, "once tomorrow arrives");
    } else {
      result = result.replace(/^So I was thinking of going out\b/gi, "I was considering heading out");
      result = result.replace(/^So I was thinking of\b/gi, "I was considering");
      result = result.replace(/^So I\b/gi, "Consequently, I");
      result = result.replace(/\bthinking of going out\b/gi, "considering heading out");
      result = result.replace(/\bthinking of\b/gi, "considering");
      result = result.replace(/\bgoing out\b/gi, "heading out");
      result = result.replace(/\bwant to\b/gi, "would like to");
      result = result.replace(/\bneed to\b/gi, "have to");
      result = result.replace(/\btrying to\b/gi, "attempting to");
      result = result.replace(/\bhelp with\b/gi, "assist with");
      result = result.replace(/\bmake sure\b/gi, "ensure");
      result = result.replace(/\btalk about\b/gi, "discuss");
      result = result.replace(/\bfind out\b/gi, "discover");
      result = result.replace(/\bin order to\b/gi, "to");
      result = result.replace(/\bat this point in time\b/gi, "currently");
      result = result.replace(/\bdue to the fact that\b/gi, "because");
      result = result.replace(/\butilize\b/gi, "use");
      result = result.replace(/\bvery good\b/gi, "exceptional");
    }
    if (!forChecker && result.trim().toLowerCase() === text.trim().toLowerCase()) {
      const l = result.trim().toLowerCase();
      if (mode === "formal") {
        if (!l.startsWith("it should be noted that") && !l.startsWith("consequently") && !l.startsWith("therefore")) {
          result = `It should be noted that ${result.charAt(0).toLowerCase() + result.slice(1)}`;
        }
      } else if (mode === "expand") {
        if (!l.endsWith("take into account.") && !l.endsWith("take into account")) {
          result = `${result.replace(/[.?!]?$/, "")}, which is particularly significant to take into account.`;
        }
      } else if (mode === "shorten") {
        result = result.replace(/^(however|furthermore|moreover|consequently|therefore|additionally),?\s*/i, "");
        if (result.length > 20) {
          result = result.replace(/\b(that|which|who|whom)\b/gi, "");
        }
      } else if (mode === "fluency") {
        if (!l.startsWith("clearly,") && !l.startsWith("honestly,") && !l.startsWith("naturally,")) {
          result = `Clearly, ${result.charAt(0).toLowerCase() + result.slice(1)}`;
        }
      } else {
        if (!l.startsWith("in essence,") && !l.startsWith("basically,") && !l.startsWith("in summary,")) {
          result = `In essence, ${result.charAt(0).toLowerCase() + result.slice(1)}`;
        }
      }
    }
    result = result.trim();
    if (result.length > 0) {
      result = result.charAt(0).toUpperCase() + result.slice(1);
    }
    if (!/[.?!]$/.test(result)) {
      if (/^(can|could|would|will|do|did|does|is|are|was|were|what|where|when|why|how)\b/i.test(result)) {
        result = `${result}?`;
      } else {
        result = `${result}.`;
      }
    }
    return result;
  }

  // apps/chrome-extension/src/content.ts
  var activeElement = null;
  var currentSuggestions = [];
  var personalDictionary = /* @__PURE__ */ new Set();
  var isExtensionEnabled = true;
  var debounceTimer = null;
  var floatingBtn = null;
  var underlineLayer = null;
  var tooltipElement = null;
  var modalElement = null;
  var activeParaphraseMode = "standard";
  var dismissedRephrases = /* @__PURE__ */ new Set();
  chrome.storage.sync.get(["lingually_enabled", "lingually_dictionary"], (res) => {
    if (res.lingually_enabled !== void 0) {
      isExtensionEnabled = Boolean(res.lingually_enabled);
    }
    if (Array.isArray(res.lingually_dictionary)) {
      personalDictionary = new Set(res.lingually_dictionary.map((w) => w.toLowerCase()));
    }
  });
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.lingually_enabled) {
      isExtensionEnabled = Boolean(changes.lingually_enabled.newValue);
      if (!isExtensionEnabled) {
        removeUI();
      }
    }
    if (changes.lingually_dictionary) {
      const list = changes.lingually_dictionary.newValue || [];
      personalDictionary = new Set(list.map((w) => w.toLowerCase()));
      if (activeElement) {
        checkActiveElement();
      }
    }
  });
  function isEditable(el) {
    if (!el) return false;
    if (el.closest(".lingually-modal") || el.closest(".lingually-tooltip") || el.closest(".lingually-floating-btn")) {
      return false;
    }
    const tag = el.tagName.toLowerCase();
    if (tag === "textarea") return true;
    if (tag === "input") {
      const inputType = el.type.toLowerCase();
      return ["text", "search", "email", "url", ""].includes(inputType);
    }
    return el.isContentEditable || el.getAttribute("contenteditable") === "true";
  }
  function getText(el) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      return el.value;
    }
    return el.innerText || el.textContent || "";
  }
  function setText(el, newText) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      const start = el.selectionStart;
      const end = el.selectionEnd;
      el.value = newText;
      if (start !== null && end !== null) {
        el.setSelectionRange(Math.min(start, newText.length), Math.min(end, newText.length));
      }
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else if (el.isContentEditable) {
      el.innerText = newText;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  function removeUI() {
    if (floatingBtn && floatingBtn.parentNode) {
      floatingBtn.parentNode.removeChild(floatingBtn);
      floatingBtn = null;
    }
    if (underlineLayer && underlineLayer.parentNode) {
      underlineLayer.parentNode.removeChild(underlineLayer);
      underlineLayer = null;
    }
    if (tooltipElement && tooltipElement.parentNode) {
      tooltipElement.parentNode.removeChild(tooltipElement);
      tooltipElement = null;
    }
    if (modalElement && modalElement.parentNode) {
      modalElement.parentNode.removeChild(modalElement);
      modalElement = null;
    }
  }
  function updatePositions() {
    if (!activeElement) return;
    updateFloatingBtnPosition();
    renderUnderlines();
  }
  function updateFloatingBtnPosition() {
    if (!floatingBtn || !activeElement) return;
    const rect = activeElement.getBoundingClientRect();
    const scrollX = window.scrollX || window.pageXOffset;
    const scrollY = window.scrollY || window.pageYOffset;
    const top = scrollY + rect.bottom - (rect.height > 44 ? 36 : 30);
    const left = scrollX + rect.right - 36;
    floatingBtn.style.top = `${Math.max(scrollY + 4, top)}px`;
    floatingBtn.style.left = `${Math.max(scrollX + 4, left)}px`;
  }
  function renderFloatingBtn(count) {
    if (!activeElement || !isExtensionEnabled) {
      removeUI();
      return;
    }
    if (!floatingBtn) {
      floatingBtn = document.createElement("div");
      floatingBtn.className = "lingually-floating-btn";
      floatingBtn.title = "Lingually Writing Assistant";
      const brandIconUrl = chrome.runtime.getURL("icons/icon32.png");
      floatingBtn.innerHTML = `
      <img class="lingually-floating-icon-img" src="${brandIconUrl}" alt="Lingually" />
      <div class="lingually-floating-badge" id="lingually-badge-el"></div>
    `;
      floatingBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        e.preventDefault();
        toggleModal();
      });
      document.body.appendChild(floatingBtn);
    }
    const badgeEl = floatingBtn.querySelector("#lingually-badge-el");
    if (badgeEl) {
      if (count > 0) {
        badgeEl.className = "lingually-floating-badge";
        badgeEl.textContent = count > 99 ? "99+" : String(count);
        badgeEl.style.display = "flex";
      } else {
        badgeEl.className = "lingually-floating-badge lingually-floating-badge-clean";
        badgeEl.textContent = "";
        badgeEl.style.display = "block";
      }
    }
    updateFloatingBtnPosition();
  }
  function ensureUnderlineLayer() {
    if (!underlineLayer || !underlineLayer.parentNode) {
      underlineLayer = document.createElement("div");
      underlineLayer.className = "lingually-underline-layer";
      document.documentElement.appendChild(underlineLayer);
    }
    underlineLayer.innerHTML = "";
  }
  var inputMirror = null;
  function getInputMirror() {
    if (!inputMirror) {
      inputMirror = document.createElement("div");
      inputMirror.id = "lingually-input-mirror";
      inputMirror.style.position = "fixed";
      inputMirror.style.top = "-9999px";
      inputMirror.style.left = "-9999px";
      inputMirror.style.visibility = "hidden";
      inputMirror.style.pointerEvents = "none";
      inputMirror.style.whiteSpace = "pre-wrap";
      inputMirror.style.wordWrap = "break-word";
      inputMirror.style.overflowWrap = "break-word";
      inputMirror.style.boxSizing = "border-box";
      document.documentElement.appendChild(inputMirror);
    }
    return inputMirror;
  }
  function copyInputStyles(source, target) {
    const cs = window.getComputedStyle(source);
    target.style.fontFamily = cs.fontFamily;
    target.style.fontSize = cs.fontSize;
    target.style.fontWeight = cs.fontWeight;
    target.style.fontStyle = cs.fontStyle;
    target.style.lineHeight = cs.lineHeight;
    target.style.letterSpacing = cs.letterSpacing;
    target.style.textTransform = cs.textTransform;
    target.style.paddingTop = cs.paddingTop;
    target.style.paddingRight = cs.paddingRight;
    target.style.paddingBottom = cs.paddingBottom;
    target.style.paddingLeft = cs.paddingLeft;
    target.style.borderTopWidth = cs.borderTopWidth;
    target.style.borderLeftWidth = cs.borderLeftWidth;
    target.style.boxSizing = cs.boxSizing;
    target.style.width = `${source.clientWidth}px`;
    if (source instanceof HTMLInputElement) {
      target.style.whiteSpace = "pre";
    } else {
      target.style.whiteSpace = "pre-wrap";
    }
  }
  function renderUnderlines() {
    if (!activeElement || !isExtensionEnabled || currentSuggestions.length === 0) {
      if (underlineLayer) underlineLayer.innerHTML = "";
      return;
    }
    ensureUnderlineLayer();
    if (!underlineLayer) return;
    const scrollX = window.scrollX || window.pageXOffset;
    const scrollY = window.scrollY || window.pageYOffset;
    const elemRect = activeElement.getBoundingClientRect();
    if (activeElement.isContentEditable) {
      renderContentEditableUnderlines(activeElement, scrollX, scrollY);
    } else if (activeElement instanceof HTMLTextAreaElement || activeElement instanceof HTMLInputElement) {
      renderInputUnderlines(activeElement, elemRect, scrollX, scrollY);
    }
  }
  function renderContentEditableUnderlines(container, scrollX, scrollY) {
    if (!underlineLayer) return;
    const textNodes = [];
    let currentOffset = 0;
    function collectTextNodes(node) {
      if (node.nodeType === Node.TEXT_NODE) {
        const text = node.textContent || "";
        textNodes.push({
          node,
          start: currentOffset,
          end: currentOffset + text.length
        });
        currentOffset += text.length;
      } else {
        for (let i = 0; i < node.childNodes.length; i++) {
          collectTextNodes(node.childNodes[i]);
        }
      }
    }
    collectTextNodes(container);
    currentSuggestions.forEach((s) => {
      const sStart = s.offset;
      const sEnd = s.offset + s.length;
      for (const t of textNodes) {
        if (sStart < t.end && sEnd > t.start) {
          const nodeStart = Math.max(0, sStart - t.start);
          const nodeEnd = Math.min(t.node.length, sEnd - t.start);
          try {
            const range = document.createRange();
            range.setStart(t.node, nodeStart);
            range.setEnd(t.node, nodeEnd);
            const rects = range.getClientRects();
            for (let i = 0; i < rects.length; i++) {
              const r = rects[i];
              if (r.width === 0 || r.height === 0) continue;
              const u = document.createElement("div");
              u.className = `lingually-underline lingually-underline-${s.category}`;
              u.style.top = `${scrollY + r.bottom - 3}px`;
              u.style.left = `${scrollX + r.left}px`;
              u.style.width = `${r.width}px`;
              u.addEventListener("mouseenter", (e) => {
                e.stopPropagation();
                showTooltip(s, r, scrollX, scrollY);
              });
              u.addEventListener("click", (e) => {
                e.stopPropagation();
                showTooltip(s, r, scrollX, scrollY);
              });
              underlineLayer?.appendChild(u);
            }
          } catch {
          }
        }
      }
    });
  }
  function renderInputUnderlines(input, elemRect, scrollX, scrollY) {
    if (!underlineLayer) return;
    const fullText = input.value;
    if (!fullText) return;
    const mirror = getInputMirror();
    copyInputStyles(input, mirror);
    currentSuggestions.forEach((s) => {
      const before = fullText.slice(0, s.offset);
      const target = fullText.slice(s.offset, s.offset + s.length);
      mirror.textContent = "";
      mirror.appendChild(document.createTextNode(before));
      const marker = document.createElement("span");
      marker.textContent = target;
      mirror.appendChild(marker);
      const mirrorRect = mirror.getBoundingClientRect();
      const clientRects = marker.getClientRects();
      for (let i = 0; i < clientRects.length; i++) {
        const cr = clientRects[i];
        if (cr.width === 0 || cr.height === 0) continue;
        const spanLeft = cr.left - mirrorRect.left;
        const spanTop = cr.top - mirrorRect.top;
        const spanWidth = cr.width;
        const spanHeight = cr.height;
        const left = elemRect.left + spanLeft - input.scrollLeft;
        const top = elemRect.top + spanTop + spanHeight - input.scrollTop;
        if (left >= elemRect.left - 4 && left + 4 <= elemRect.right && top >= elemRect.top && top <= elemRect.bottom + 8) {
          const u = document.createElement("div");
          u.className = `lingually-underline lingually-underline-${s.category}`;
          u.style.top = `${scrollY + top - 2}px`;
          u.style.left = `${scrollX + left}px`;
          u.style.width = `${Math.max(12, spanWidth)}px`;
          const r = {
            left,
            top: top - spanHeight,
            bottom: top,
            right: left + spanWidth,
            width: spanWidth,
            height: spanHeight
          };
          u.addEventListener("mouseenter", (e) => {
            e.stopPropagation();
            showTooltip(s, r, scrollX, scrollY);
          });
          u.addEventListener("click", (e) => {
            e.stopPropagation();
            showTooltip(s, r, scrollX, scrollY);
          });
          underlineLayer?.appendChild(u);
        }
      }
    });
  }
  function showTooltip(s, rect, scrollX, scrollY) {
    if (tooltipElement && tooltipElement.parentNode) {
      tooltipElement.parentNode.removeChild(tooltipElement);
      tooltipElement = null;
    }
    tooltipElement = document.createElement("div");
    tooltipElement.className = "lingually-tooltip";
    const top = scrollY + rect.bottom + 6;
    const left = Math.min(scrollX + rect.left, window.innerWidth + scrollX - 310);
    tooltipElement.style.top = `${top}px`;
    tooltipElement.style.left = `${Math.max(scrollX + 8, left)}px`;
    const isRemoval = s.replacementText === "";
    const isRephrase = s.explanation.toLowerCase().includes("rephrase");
    const suggestedDisplay = isRemoval ? `<span class="lingually-suggested-remove">[Remove word]</span>` : `<span class="lingually-suggested">${escapeHtml(s.replacementText)}</span>`;
    const acceptBtnText = isRemoval ? "Remove" : isRephrase ? "Accept Rephrase" : "Accept";
    const badgeText = isRemoval ? "UNRECOGNIZED" : isRephrase ? "REPHRASE" : s.category;
    tooltipElement.innerHTML = `
    <div class="lingually-tooltip-header">
      <span class="lingually-cat-badge lingually-cat-${s.category}">${badgeText}</span>
      <span style="font-size: 11px; color: #94a3b8; cursor: pointer;" id="tooltip-close-btn">&times;</span>
    </div>
    <div class="lingually-tooltip-body">
      <span class="lingually-strikethrough">${escapeHtml(s.originalText)}</span>
      <span class="lingually-arrow">&rarr;</span>
      ${suggestedDisplay}
    </div>
    <div class="lingually-tooltip-reason">${escapeHtml(s.explanation)}</div>
    <div class="lingually-tooltip-actions">
      <button class="lingually-btn-accept ${isRemoval ? "lingually-btn-remove" : ""}" id="tooltip-accept-btn">${acceptBtnText}</button>
      ${isRephrase ? `<button class="lingually-btn-dismiss" id="tooltip-open-modal-btn">Paraphrase Modes</button>` : ""}
      <button class="lingually-btn-dismiss" id="tooltip-dismiss-btn">Ignore</button>
    </div>
    ${!isRephrase ? `<button class="lingually-btn-dict-link" id="tooltip-dict-btn">Add "${escapeHtml(s.originalText)}" to dictionary</button>` : ""}
  `;
    document.body.appendChild(tooltipElement);
    tooltipElement.querySelector("#tooltip-accept-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      applySuggestion(s);
      dismissTooltip();
    });
    tooltipElement.querySelector("#tooltip-open-modal-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dismissTooltip();
      openModal();
      const tabParaBtn = modalElement?.querySelector("#tab-btn-paraphrase");
      tabParaBtn?.click();
    });
    tooltipElement.querySelector("#tooltip-dismiss-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dismissSuggestion(s);
      dismissTooltip();
    });
    tooltipElement.querySelector("#tooltip-close-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dismissTooltip();
    });
    tooltipElement.querySelector("#tooltip-dict-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      addToDictionary(s.originalText);
      dismissTooltip();
    });
  }
  function dismissTooltip() {
    if (tooltipElement && tooltipElement.parentNode) {
      tooltipElement.parentNode.removeChild(tooltipElement);
      tooltipElement = null;
    }
  }
  function makeDraggable(modal, handle) {
    let isDragging = false;
    let startX = 0;
    let startY = 0;
    let initialLeft = 0;
    let initialTop = 0;
    handle.addEventListener("mousedown", (e) => {
      if (e.target.closest(".lingually-modal-close") || e.target.closest(".lingually-modal-btn-icon")) {
        return;
      }
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = modal.getBoundingClientRect();
      initialLeft = rect.left + (window.scrollX || window.pageXOffset);
      initialTop = rect.top + (window.scrollY || window.pageYOffset);
      const onMouseMove = (ev) => {
        if (!isDragging) return;
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        modal.style.left = `${Math.max(10, initialLeft + dx)}px`;
        modal.style.top = `${Math.max(10, initialTop + dy)}px`;
      };
      const onMouseUp = () => {
        isDragging = false;
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
      };
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    });
  }
  function toggleModal() {
    if (modalElement) {
      closeModal();
    } else {
      openModal();
    }
  }
  function getReviewSuggestions() {
    return currentSuggestions.filter(
      (s) => !s.id.startsWith("ext_rephrase") && !s.explanation.toLowerCase().includes("rephrase")
    );
  }
  function getRephraseSuggestion() {
    return currentSuggestions.find(
      (s) => s.id.startsWith("ext_rephrase") || s.explanation.toLowerCase().includes("rephrase")
    );
  }
  function openModal(initialTab = "review") {
    if (!activeElement) return;
    if (modalElement) closeModal();
    modalElement = document.createElement("div");
    modalElement.className = "lingually-modal";
    modalElement.addEventListener("click", (e) => {
      e.stopPropagation();
    });
    const rect = activeElement.getBoundingClientRect();
    const scrollX = window.scrollX || window.pageXOffset;
    const scrollY = window.scrollY || window.pageYOffset;
    let top = scrollY + rect.bottom + 8;
    let left = scrollX + rect.right - 380;
    if (left < scrollX + 16) left = scrollX + 16;
    if (top + 460 > window.innerHeight + scrollY) {
      top = Math.max(scrollY + 16, scrollY + rect.top - 460);
    }
    modalElement.style.top = `${top}px`;
    modalElement.style.left = `${left}px`;
    const brandIconUrl = chrome.runtime.getURL("icons/icon32.png");
    const reviewCount = getReviewSuggestions().length;
    modalElement.innerHTML = `
    <div class="lingually-modal-header" id="modal-drag-header" title="Drag to reposition">
      <div class="lingually-modal-brand">
        <img src="${brandIconUrl}" style="width: 18px; height: 18px; border-radius: 4px; object-fit: contain;" alt="Lingually" />
        <span>Lingually Assistant</span>
      </div>
      <div class="lingually-modal-header-actions">
        <button class="lingually-modal-btn-icon" id="modal-refresh-btn" title="Refresh analysis">
          <svg class="lingually-refresh-icon" style="width: 14px; height: 14px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>
          </svg>
        </button>
        <button class="lingually-modal-close" id="modal-close-x" title="Close">&times;</button>
      </div>
    </div>

    <div class="lingually-modal-tabs">
      <button class="lingually-tab-btn ${initialTab === "review" ? "active" : ""}" id="tab-btn-review">
        01 // REVIEW (<span id="modal-review-count">${reviewCount}</span>)
      </button>
      <button class="lingually-tab-btn ${initialTab === "paraphrase" ? "active" : ""}" id="tab-btn-paraphrase">
        02 // PARAPHRASE
      </button>
    </div>

    <div class="lingually-modal-content">
      <div id="pane-review" style="display: ${initialTab === "review" ? "block" : "none"};"></div>
      <div id="pane-paraphrase" style="display: ${initialTab === "paraphrase" ? "block" : "none"};"></div>
    </div>
  `;
    document.body.appendChild(modalElement);
    const header = modalElement.querySelector("#modal-drag-header");
    if (header) makeDraggable(modalElement, header);
    modalElement.querySelector("#modal-refresh-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      const btn = modalElement?.querySelector("#modal-refresh-btn");
      const icon = btn?.querySelector("svg");
      icon?.classList.add("lingually-spin");
      checkActiveElement();
      updateReviewPane();
      updateParaphrasePane();
      setTimeout(() => {
        icon?.classList.remove("lingually-spin");
      }, 400);
    });
    modalElement.querySelector("#modal-close-x")?.addEventListener("click", (e) => {
      e.stopPropagation();
      closeModal();
    });
    const tabReviewBtn = modalElement.querySelector("#tab-btn-review");
    const tabParaBtn = modalElement.querySelector("#tab-btn-paraphrase");
    const paneReview = modalElement.querySelector("#pane-review");
    const panePara = modalElement.querySelector("#pane-paraphrase");
    tabReviewBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      tabReviewBtn.classList.add("active");
      tabParaBtn.classList.remove("active");
      paneReview.style.display = "block";
      panePara.style.display = "none";
      updateReviewPane();
    });
    tabParaBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      tabParaBtn.classList.add("active");
      tabReviewBtn.classList.remove("active");
      paneReview.style.display = "none";
      panePara.style.display = "block";
      updateParaphrasePane();
    });
    updateReviewPane();
    updateParaphrasePane();
  }
  function closeModal() {
    if (modalElement && modalElement.parentNode) {
      modalElement.parentNode.removeChild(modalElement);
      modalElement = null;
    }
  }
  function updateReviewPane() {
    if (!modalElement || !activeElement) return;
    const paneReview = modalElement.querySelector("#pane-review");
    if (!paneReview) return;
    const reviewSuggestions = getReviewSuggestions();
    const countSpan = modalElement.querySelector("#modal-review-count");
    if (countSpan) countSpan.textContent = String(reviewSuggestions.length);
    const score = Math.max(40, 100 - reviewSuggestions.length * 10);
    if (reviewSuggestions.length === 0) {
      paneReview.innerHTML = `
      <div class="lingually-empty-review">
        <div class="lingually-empty-icon">&#10003;</div>
        <div style="font-weight: 700; color: #0f172a; margin-bottom: 4px;">Writing looks clear!</div>
        <div>No spelling or grammar errors detected.</div>
      </div>
    `;
      return;
    }
    paneReview.innerHTML = `
    <div class="lingually-score-banner">
      <div>Writing Health Score: <span class="lingually-score-value">${score}/100</span></div>
      ${reviewSuggestions.length > 1 ? `<button class="lingually-btn-fix-all" id="btn-fix-all">Fix All (${reviewSuggestions.length})</button>` : ""}
    </div>
    <div class="lingually-issues-list" id="modal-issues-list"></div>
  `;
    const listEl = paneReview.querySelector("#modal-issues-list");
    reviewSuggestions.forEach((s) => {
      const isRemoval = s.replacementText === "";
      const suggestedDisplay = isRemoval ? `<span class="lingually-suggested-remove">[Remove word]</span>` : `<span class="lingually-suggested">${escapeHtml(s.replacementText)}</span>`;
      const acceptBtnText = isRemoval ? "Remove" : "Accept";
      const badgeText = isRemoval ? "UNRECOGNIZED" : s.category;
      const item = document.createElement("div");
      item.className = "lingually-issue-card";
      item.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
        <span class="lingually-cat-badge lingually-cat-${s.category}">${badgeText}</span>
      </div>
      <div class="lingually-tooltip-body" style="margin: 4px 0;">
        <span class="lingually-strikethrough">${escapeHtml(s.originalText)}</span>
        <span class="lingually-arrow">&rarr;</span>
        ${suggestedDisplay}
      </div>
      <div class="lingually-tooltip-reason" style="margin-bottom: 8px;">${escapeHtml(s.explanation)}</div>
      <div class="lingually-tooltip-actions">
        <button class="lingually-btn-accept ${isRemoval ? "lingually-btn-remove" : ""}">${acceptBtnText}</button>
        <button class="lingually-btn-dismiss">Ignore</button>
      </div>
      <button class="lingually-btn-dict-link" style="margin-top: 6px;">Add "${escapeHtml(s.originalText)}" to dictionary</button>
    `;
      item.querySelector(".lingually-btn-accept")?.addEventListener("click", (e) => {
        e.stopPropagation();
        applySuggestion(s);
        updateReviewPane();
        updateParaphrasePane();
      });
      item.querySelector(".lingually-btn-dismiss")?.addEventListener("click", (e) => {
        e.stopPropagation();
        dismissSuggestion(s);
        updateReviewPane();
      });
      item.querySelector(".lingually-btn-dict-link")?.addEventListener("click", (e) => {
        e.stopPropagation();
        addToDictionary(s.originalText);
        updateReviewPane();
      });
      listEl.appendChild(item);
    });
    paneReview.querySelector("#btn-fix-all")?.addEventListener("click", (e) => {
      e.stopPropagation();
      fixAllSuggestions();
      updateReviewPane();
      updateParaphrasePane();
    });
  }
  function updateParaphrasePane() {
    if (!modalElement || !activeElement) return;
    const panePara = modalElement.querySelector("#pane-paraphrase");
    if (!panePara) return;
    const currentText = getText(activeElement);
    const rephraseSugg = getRephraseSuggestion();
    panePara.innerHTML = `
    ${rephraseSugg ? `
      <div class="lingually-rephrase-box-modal" style="background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 8px; padding: 12px; margin-bottom: 14px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
          <span class="lingually-cat-badge lingually-cat-clarity">SUGGESTED REPHRASE</span>
        </div>
        <div class="lingually-tooltip-body" style="margin: 4px 0;">
          <span class="lingually-strikethrough">${escapeHtml(rephraseSugg.originalText)}</span>
          <span class="lingually-arrow">&rarr;</span>
          <span class="lingually-suggested" style="color: #0284c7;">${escapeHtml(rephraseSugg.replacementText)}</span>
        </div>
        <div class="lingually-tooltip-reason" style="margin-bottom: 8px;">${escapeHtml(rephraseSugg.explanation)}</div>
        <div class="lingually-tooltip-actions">
          <button class="lingually-btn-accept" id="btn-modal-accept-rephrase" style="background: #0284c7; border-color: #0284c7;">Accept Rephrase</button>
          <button class="lingually-btn-dismiss" id="btn-modal-dismiss-rephrase">Ignore</button>
        </div>
      </div>
    ` : ""}

    <div style="font-size: 11px; font-weight: 600; color: #475569; margin-bottom: 6px;">PARAPHRASE MODE</div>
    <div class="lingually-mode-selector">
      <button class="lingually-mode-chip ${activeParaphraseMode === "standard" ? "active" : ""}" data-mode="standard">Standard</button>
      <button class="lingually-mode-chip ${activeParaphraseMode === "fluency" ? "active" : ""}" data-mode="fluency">Fluency</button>
      <button class="lingually-mode-chip ${activeParaphraseMode === "formal" ? "active" : ""}" data-mode="formal">Formal</button>
      <button class="lingually-mode-chip ${activeParaphraseMode === "shorten" ? "active" : ""}" data-mode="shorten">Shorten</button>
      <button class="lingually-mode-chip ${activeParaphraseMode === "expand" ? "active" : ""}" data-mode="expand">Expand</button>
    </div>

    <div style="font-size: 11px; font-weight: 600; color: #475569; margin-bottom: 4px;">CURRENT TEXT</div>
    <div class="lingually-paraphrase-box" id="para-input-preview">${escapeHtml(currentText || "(No text entered in field)")}</div>

    <button class="lingually-btn-paraphrase" id="btn-run-paraphrase">
      <svg style="width: 14px; height: 14px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="23 4 23 10 17 10"></polyline>
        <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
      </svg>
      <span>Paraphrase with Lingually</span>
    </button>

    <div class="lingually-paraphrase-output" id="para-output-area" style="display: none;">
      <div style="font-size: 11px; font-weight: 600; color: #059669; margin-bottom: 4px;">PARAPHRASED REWRITE</div>
      <div class="lingually-paraphrase-box" id="para-output-text" style="background: #f0fdf4; border-color: #bbf7d0;"></div>
      <div class="lingually-paraphrase-actions">
        <button class="lingually-btn-replace" id="btn-insert-page">Replace in Text Field</button>
        <button class="lingually-btn-copy" id="btn-copy-para">Copy</button>
      </div>
    </div>
  `;
    if (rephraseSugg) {
      panePara.querySelector("#btn-modal-accept-rephrase")?.addEventListener("click", (e) => {
        e.stopPropagation();
        applySuggestion(rephraseSugg);
        updateReviewPane();
        updateParaphrasePane();
      });
      panePara.querySelector("#btn-modal-dismiss-rephrase")?.addEventListener("click", (e) => {
        e.stopPropagation();
        dismissSuggestion(rephraseSugg);
        updateParaphrasePane();
      });
    }
    panePara.innerHTML = `
    <div style="font-size: 11px; font-weight: 600; color: #475569; margin-bottom: 6px;">PARAPHRASE MODE</div>
    <div class="lingually-mode-selector">
      <button class="lingually-mode-chip ${activeParaphraseMode === "standard" ? "active" : ""}" data-mode="standard">Standard</button>
      <button class="lingually-mode-chip ${activeParaphraseMode === "fluency" ? "active" : ""}" data-mode="fluency">Fluency</button>
      <button class="lingually-mode-chip ${activeParaphraseMode === "formal" ? "active" : ""}" data-mode="formal">Formal</button>
      <button class="lingually-mode-chip ${activeParaphraseMode === "shorten" ? "active" : ""}" data-mode="shorten">Shorten</button>
      <button class="lingually-mode-chip ${activeParaphraseMode === "expand" ? "active" : ""}" data-mode="expand">Expand</button>
    </div>

    <div style="font-size: 11px; font-weight: 600; color: #475569; margin-bottom: 4px;">CURRENT TEXT</div>
    <div class="lingually-paraphrase-box" id="para-input-preview">${escapeHtml(currentText || "(No text entered in field)")}</div>

    <button class="lingually-btn-paraphrase" id="btn-run-paraphrase">
      <svg style="width: 14px; height: 14px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="23 4 23 10 17 10"></polyline>
        <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
      </svg>
      <span>Paraphrase with Lingually</span>
    </button>

    <div class="lingually-paraphrase-output" id="para-output-area" style="display: none;">
      <div style="font-size: 11px; font-weight: 600; color: #059669; margin-bottom: 4px;">PARAPHRASED REWRITE</div>
      <div class="lingually-paraphrase-box" id="para-output-text" style="background: #f0fdf4; border-color: #bbf7d0;"></div>
      <div class="lingually-paraphrase-actions">
        <button class="lingually-btn-replace" id="btn-insert-page">Replace in Text Field</button>
        <button class="lingually-btn-copy" id="btn-copy-para">Copy</button>
      </div>
    </div>
  `;
    let currentParaphraseOutput = "";
    const runParaphrase = () => {
      const textToRewrite = getText(activeElement);
      if (!textToRewrite || textToRewrite.trim().length === 0) return;
      const btn = panePara.querySelector("#btn-run-paraphrase");
      if (btn) {
        btn.innerHTML = `<span>Paraphrasing...</span>`;
        btn.disabled = true;
      }
      setTimeout(() => {
        currentParaphraseOutput = paraphraseText(textToRewrite, activeParaphraseMode);
        const outputArea = panePara.querySelector("#para-output-area");
        const outputText = panePara.querySelector("#para-output-text");
        if (outputText) outputText.textContent = currentParaphraseOutput;
        if (outputArea) outputArea.style.display = "block";
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = `
          <svg style="width: 14px; height: 14px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"></polyline>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
          </svg>
          <span>Re-paraphrase</span>
        `;
        }
      }, 120);
    };
    panePara.querySelectorAll(".lingually-mode-chip").forEach((chip) => {
      chip.addEventListener("click", (e) => {
        e.stopPropagation();
        panePara.querySelectorAll(".lingually-mode-chip").forEach((c) => c.classList.remove("active"));
        chip.classList.add("active");
        activeParaphraseMode = chip.getAttribute("data-mode");
        runParaphrase();
      });
    });
    panePara.querySelector("#btn-run-paraphrase")?.addEventListener("click", (e) => {
      e.stopPropagation();
      runParaphrase();
    });
    panePara.querySelector("#btn-insert-page")?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (activeElement && currentParaphraseOutput) {
        setText(activeElement, currentParaphraseOutput);
        checkActiveElement();
        updateReviewPane();
        updateParaphrasePane();
      }
    });
    panePara.querySelector("#btn-copy-para")?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (currentParaphraseOutput) {
        navigator.clipboard.writeText(currentParaphraseOutput);
        const copyBtn = panePara.querySelector("#btn-copy-para");
        copyBtn.textContent = "Copied!";
        setTimeout(() => {
          copyBtn.textContent = "Copy";
        }, 1500);
      }
    });
    if (currentText && currentText.trim().length > 0) {
      runParaphrase();
    }
  }
  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function applySuggestion(s) {
    if (!activeElement) return;
    if (s.id.startsWith("ext_rephrase") || s.explanation.toLowerCase().includes("rephrase")) {
      dismissedRephrases.add(s.originalText.trim().toLowerCase());
      dismissedRephrases.add(s.replacementText.trim().toLowerCase());
    }
    const fullText = getText(activeElement);
    let before = fullText.slice(0, s.offset);
    let after = fullText.slice(s.offset + s.length);
    if (s.replacementText === "") {
      if (before.endsWith(" ") && (after.startsWith(" ") || after.length === 0 || /^[.,!?;:]/.test(after))) {
        before = before.slice(0, -1);
      } else if (before.length === 0 && after.startsWith(" ")) {
        after = after.slice(1);
      }
    }
    const updated = before + s.replacementText + after;
    setText(activeElement, updated);
    checkActiveElement();
  }
  function fixAllSuggestions() {
    if (!activeElement || currentSuggestions.length === 0) return;
    let fullText = getText(activeElement);
    const toFix = getReviewSuggestions();
    const sorted = [...toFix].sort((a, b) => b.offset - a.offset);
    for (const s of sorted) {
      let before = fullText.slice(0, s.offset);
      let after = fullText.slice(s.offset + s.length);
      if (s.replacementText === "") {
        if (before.endsWith(" ") && (after.startsWith(" ") || after.length === 0 || /^[.,!?;:]/.test(after))) {
          before = before.slice(0, -1);
        } else if (before.length === 0 && after.startsWith(" ")) {
          after = after.slice(1);
        }
      }
      fullText = before + s.replacementText + after;
    }
    setText(activeElement, fullText);
    checkActiveElement();
  }
  function dismissSuggestion(s) {
    if (s.id.startsWith("ext_rephrase") || s.explanation.toLowerCase().includes("rephrase")) {
      dismissedRephrases.add(s.originalText.trim().toLowerCase());
      dismissedRephrases.add(s.replacementText.trim().toLowerCase());
    }
    currentSuggestions = currentSuggestions.filter((item) => item.id !== s.id);
    renderFloatingBtn(getReviewSuggestions().length);
    renderUnderlines();
    if (modalElement) {
      updateReviewPane();
      updateParaphrasePane();
    }
  }
  function addToDictionary(word) {
    const cleanWord = word.trim().toLowerCase();
    personalDictionary.add(cleanWord);
    chrome.storage.sync.get(["lingually_dictionary"], (res) => {
      const existing = res.lingually_dictionary || [];
      if (!existing.includes(cleanWord)) {
        chrome.storage.sync.set({ lingually_dictionary: [...existing, cleanWord] });
      }
    });
    checkActiveElement();
  }
  function checkActiveElement() {
    if (!activeElement || !isExtensionEnabled) {
      removeUI();
      return;
    }
    const text = getText(activeElement);
    if (text.length < 2) {
      currentSuggestions = [];
      renderFloatingBtn(0);
      renderUnderlines();
      if (modalElement) {
        updateReviewPane();
        updateParaphrasePane();
      }
      return;
    }
    const rawSuggestions = runExtensionCheck(text, personalDictionary);
    currentSuggestions = rawSuggestions.filter(
      (s) => !dismissedRephrases.has(s.originalText.trim().toLowerCase()) && !dismissedRephrases.has(s.replacementText.trim().toLowerCase())
    );
    renderFloatingBtn(getReviewSuggestions().length);
    renderUnderlines();
    if (modalElement) {
      updateReviewPane();
      updateParaphrasePane();
    }
  }
  function handleEditorKeystroke(target) {
    if (isEditable(target)) {
      activeElement = target;
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        checkActiveElement();
        if (modalElement) {
          updateReviewPane();
          const paraPreview = modalElement.querySelector("#para-input-preview");
          if (paraPreview) {
            paraPreview.textContent = getText(activeElement) || "(No text entered in field)";
          }
        }
      }, 100);
    }
  }
  document.addEventListener(
    "focusin",
    (event) => {
      const target = event.target;
      if (isEditable(target)) {
        activeElement = target;
        checkActiveElement();
      }
    },
    true
  );
  document.addEventListener(
    "input",
    (event) => {
      handleEditorKeystroke(event.target);
    },
    true
  );
  document.addEventListener(
    "keyup",
    (event) => {
      const key = event.key;
      if (["Shift", "Control", "Alt", "Meta", "Escape"].includes(key)) return;
      handleEditorKeystroke(event.target);
    },
    true
  );
  document.addEventListener(
    "paste",
    (event) => {
      handleEditorKeystroke(event.target);
    },
    true
  );
  document.addEventListener(
    "cut",
    (event) => {
      handleEditorKeystroke(event.target);
    },
    true
  );
  document.addEventListener("click", (event) => {
    const target = event.target;
    if (tooltipElement && !tooltipElement.contains(target) && !target.classList.contains("lingually-underline")) {
      dismissTooltip();
    }
    if (modalElement && !modalElement.contains(target) && floatingBtn && !floatingBtn.contains(target) && !target.classList.contains("lingually-floating-btn")) {
      closeModal();
    }
  });
  window.addEventListener("scroll", updatePositions, { passive: true });
  window.addEventListener("resize", updatePositions, { passive: true });
})();
