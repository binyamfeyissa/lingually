"use strict";
(() => {
  // apps/chrome-extension/src/shared-checker.ts
  var DETERMINISTIC_TYPOS = {
    teh: { replacement: "the", explanation: "Corrects typographical inversion." },
    recieve: { replacement: "receive", explanation: "Remember 'i' before 'e' except after 'c'." },
    seperate: { replacement: "separate", explanation: "Correct spelling contains 'para'." },
    definately: { replacement: "definitely", explanation: "Derived from 'finite'." },
    occured: { replacement: "occurred", explanation: "Double 'r' in occurred." },
    untill: { replacement: "until", explanation: "Until has a single 'l'." },
    truely: { replacement: "truly", explanation: "Drop the 'e' in truly." },
    wierd: { replacement: "weird", explanation: "Exception to the 'i before e' rule." },
    acheive: { replacement: "achieve", explanation: "'i' before 'e' in achieve." },
    goverment: { replacement: "government", explanation: "Includes 'n' from govern." },
    tommorrow: { replacement: "tomorrow", explanation: "One 'm', double 'r'." },
    alot: { replacement: "a lot", explanation: "'A lot' is two separate words." },
    noone: { replacement: "no one", explanation: "'No one' is written as two separate words." },
    beleive: { replacement: "believe", explanation: "'i' before 'e' in believe." },
    calender: { replacement: "calendar", explanation: "Spelled with 'ar' at the end." },
    accomodate: { replacement: "accommodate", explanation: "Double 'c' and double 'm'." },
    neccessary: { replacement: "necessary", explanation: "One 'c', double 's'." },
    embarass: { replacement: "embarrass", explanation: "Double 'r' and double 's'." },
    wether: { replacement: "whether", explanation: "Use 'whether' for alternatives or 'weather' for climate." },
    witch: { replacement: "which", explanation: "Use 'which' for choices/clauses." },
    thier: { replacement: "their", explanation: "'e' before 'i' in their." },
    grammer: { replacement: "grammar", explanation: "Spelled with 'ar' at the end." },
    begining: { replacement: "beginning", explanation: "Double 'n' in beginning." },
    realy: { replacement: "really", explanation: "Double 'l' in really." },
    mispell: { replacement: "misspell", explanation: "Double 's' in misspell." },
    suprise: { replacement: "surprise", explanation: "Contains 'r' in the first syllable." },
    succesful: { replacement: "successful", explanation: "Double 'c' and double 's'." },
    publically: { replacement: "publicly", explanation: "Standard spelling is 'publicly'." },
    noticable: { replacement: "noticeable", explanation: "Retain the 'e' in noticeable." },
    independant: { replacement: "independent", explanation: "Ends in 'ent'." },
    gaurantee: { replacement: "guarantee", explanation: "'u' before 'a' in guarantee." },
    foriegn: { replacement: "foreign", explanation: "'e' before 'i' in foreign." },
    enviroment: { replacement: "environment", explanation: "Includes 'n' in iron." },
    dissapear: { replacement: "disappear", explanation: "One 's', double 'p'." },
    definate: { replacement: "definite", explanation: "Ends with 'ite'." },
    collegue: { replacement: "colleague", explanation: "Spelled 'colleague'." },
    catagory: { replacement: "category", explanation: "Spelled with 'e' in category." },
    alright: { replacement: "all right", explanation: "'All right' is preferred in formal writing." },
    basicly: { replacement: "basically", explanation: "Spelled 'basically'." },
    buisness: { replacement: "business", explanation: "'u' before 'i' in business." },
    concious: { replacement: "conscious", explanation: "Contains 'sc' in conscious." },
    dilema: { replacement: "dilemma", explanation: "Double 'm' in dilemma." },
    existance: { replacement: "existence", explanation: "Ends in 'ence'." },
    fascinating: { replacement: "fascinating", explanation: "Spelled with 'sc'." },
    greatful: { replacement: "grateful", explanation: "Spelled 'grateful' (not great)." },
    happend: { replacement: "happened", explanation: "Double 'p' in happened." },
    harrass: { replacement: "harass", explanation: "One 'r', double 's'." },
    humourous: { replacement: "humorous", explanation: "Drop 'u' in humorous." },
    immediatly: { replacement: "immediately", explanation: "Retain 'e' before 'ly'." },
    incidently: { replacement: "incidentally", explanation: "Contains 'al' before 'ly'." },
    interupt: { replacement: "interrupt", explanation: "Double 'r' in interrupt." },
    knowlege: { replacement: "knowledge", explanation: "Contains 'd' in knowledge." },
    liason: { replacement: "liaison", explanation: "Double 'i' in liaison." },
    millenium: { replacement: "millennium", explanation: "Double 'l' and double 'n'." },
    mischevious: { replacement: "mischievous", explanation: "Three syllables: mis-chie-vous." },
    paralell: { replacement: "parallel", explanation: "Double 'l' only in the middle." },
    posession: { replacement: "possession", explanation: "Double 's' twice in possession." },
    priviledge: { replacement: "privilege", explanation: "No 'd' in privilege." },
    pronounciation: { replacement: "pronunciation", explanation: "Spelled 'pronunciation' without 'o'." },
    questionaire: { replacement: "questionnaire", explanation: "Double 'n' in questionnaire." },
    recommand: { replacement: "recommend", explanation: "Spelled with 'e' in recommend." },
    refered: { replacement: "referred", explanation: "Double 'r' in referred." },
    relavant: { replacement: "relevant", explanation: "Spelled 'relevant'." },
    rythm: { replacement: "rhythm", explanation: "Contains 'h' after 'r' and 't'." },
    sieze: { replacement: "seize", explanation: "'e' before 'i' in seize." },
    succede: { replacement: "succeed", explanation: "Double 'e' in succeed." },
    tendancy: { replacement: "tendency", explanation: "Ends with 'ency'." },
    threshhold: { replacement: "threshold", explanation: "Single 'h' in threshold." },
    unfortunatly: { replacement: "unfortunately", explanation: "Retain 'e' in unfortunately." },
    vaccum: { replacement: "vacuum", explanation: "Single 'c', double 'u'." },
    visable: { replacement: "visible", explanation: "Spelled with 'i' in visible." },
    wierdly: { replacement: "weirdly", explanation: "Spelled 'weirdly'." }
  };
  var DETERMINISTIC_CONFUSIONS = [
    { pattern: /\bcould of\b/gi, replacement: "could have", explanation: "Use 'could have' instead of 'could of'." },
    { pattern: /\bshould of\b/gi, replacement: "should have", explanation: "Use 'should have' instead of 'should of'." },
    { pattern: /\bwould of\b/gi, replacement: "would have", explanation: "Use 'would have' instead of 'would of'." },
    { pattern: /\bmight of\b/gi, replacement: "might have", explanation: "Use 'might have' instead of 'might of'." },
    { pattern: /\bsuppose to\b/gi, replacement: "supposed to", explanation: "The past participle 'supposed to' is required." },
    { pattern: /\buse to\b/gi, replacement: "used to", explanation: "The idiom is 'used to'." },
    { pattern: /\beach others\b/gi, replacement: "each other's", explanation: "Add an apostrophe for possessive 'each other's'." },
    { pattern: /\bone anothers\b/gi, replacement: "one another's", explanation: "Add an apostrophe for possessive 'one another's'." },
    { pattern: /\bthere own\b/gi, replacement: "their own", explanation: "Use possessive 'their' with own." },
    { pattern: /\byour welcome\b/gi, replacement: "you're welcome", explanation: "Use 'you're' (you are welcome)." },
    { pattern: /\bits a\b/gi, replacement: "it's a", explanation: "Contraction 'it's' (it is a) is required." },
    { pattern: /\btheir is\b/gi, replacement: "there is", explanation: "Use 'there is' for existence." },
    { pattern: /\btheir are\b/gi, replacement: "there are", explanation: "Use 'there are' for existence." },
    { pattern: /\blose to much\b/gi, replacement: "lose too much", explanation: "'Too' means excessively." },
    { pattern: /\bto much\b/gi, replacement: "too much", explanation: "Use 'too' to mean an excessive amount." },
    { pattern: /\bto many\b/gi, replacement: "too many", explanation: "Use 'too' for excessive count." }
  ];
  var DETERMINISTIC_CLARITY = [
    { pattern: /\bin order to\b/gi, replacement: "to", explanation: "Simplify 'in order to' to simply 'to'." },
    { pattern: /\bat this point in time\b/gi, replacement: "now", explanation: "Concise alternative: 'now' or 'currently'." },
    { pattern: /\bdue to the fact that\b/gi, replacement: "because", explanation: "Simplify wordy phrase to 'because'." },
    { pattern: /\bhas the ability to\b/gi, replacement: "can", explanation: "Direct verb 'can' improves conciseness." },
    { pattern: /\bfor the purpose of\b/gi, replacement: "for", explanation: "Streamline 'for the purpose of' to 'for'." },
    { pattern: /\bin the event that\b/gi, replacement: "if", explanation: "Use 'if' for immediate clarity." },
    { pattern: /\ba large number of\b/gi, replacement: "many", explanation: "More direct and concise: 'many'." },
    { pattern: /\ba small number of\b/gi, replacement: "few", explanation: "Use 'few' instead of 'a small number of'." },
    { pattern: /\butilize\b/gi, replacement: "use", explanation: "'Use' is more direct than 'utilize'." },
    { pattern: /\butilizes\b/gi, replacement: "uses", explanation: "'Uses' is clearer than 'utilizes'." },
    { pattern: /\butilized\b/gi, replacement: "used", explanation: "'Used' is more natural." },
    { pattern: /\bat the present time\b/gi, replacement: "currently", explanation: "Use 'currently' or 'now'." },
    { pattern: /\bin spite of the fact that\b/gi, replacement: "although", explanation: "Simplify to 'although'." },
    { pattern: /\bwith the exception of\b/gi, replacement: "except", explanation: "Use 'except'." },
    { pattern: /\btake into consideration\b/gi, replacement: "consider", explanation: "Direct verb 'consider'." },
    { pattern: /\bmake a decision\b/gi, replacement: "decide", explanation: "Use the strong verb 'decide'." }
  ];
  var DETERMINISTIC_ENGAGEMENT = [
    { pattern: /\bvery good\b/gi, replacement: "exceptional", explanation: "Vivid alternative: 'exceptional' or 'superb'." },
    { pattern: /\bvery bad\b/gi, replacement: "terrible", explanation: "Expressive alternative: 'terrible' or 'dreadful'." },
    { pattern: /\bvery big\b/gi, replacement: "massive", explanation: "More vivid adjective: 'massive' or 'vast'." },
    { pattern: /\bvery small\b/gi, replacement: "tiny", explanation: "Dynamic alternative: 'tiny' or 'minuscule'." },
    { pattern: /\bvery important\b/gi, replacement: "crucial", explanation: "Stronger emphasis: 'crucial' or 'essential'." },
    { pattern: /\bvery happy\b/gi, replacement: "thrilled", explanation: "Evocative alternative: 'thrilled' or 'delighted'." },
    { pattern: /\bvery sad\b/gi, replacement: "devastated", explanation: "Expressive alternative: 'devastated'." },
    { pattern: /\bvery hard\b/gi, replacement: "challenging", explanation: "Refined adjective: 'demanding' or 'challenging'." }
  ];
  var DETERMINISTIC_DELIVERY = [
    { pattern: /\bI think that maybe\b/gi, replacement: "Perhaps", explanation: "Removes weak hedging for a more confident tone." },
    { pattern: /\bjust wondering if\b/gi, replacement: "could you", explanation: "Direct phrasing sounds more professional." },
    { pattern: /\bsorry to bother you,?\b/gi, replacement: "", explanation: "Polite but unnecessary hedging." },
    { pattern: /\byou should probably consider\b/gi, replacement: "we recommend", explanation: "Decisive phrasing sounds authoritative." }
  ];
  var COMMON_VOCABULARY = /* @__PURE__ */ new Set([
    "the",
    "be",
    "to",
    "of",
    "and",
    "a",
    "in",
    "that",
    "have",
    "i",
    "it",
    "for",
    "not",
    "on",
    "with",
    "he",
    "as",
    "you",
    "do",
    "at",
    "this",
    "but",
    "his",
    "by",
    "from",
    "they",
    "we",
    "say",
    "her",
    "she",
    "or",
    "an",
    "will",
    "my",
    "one",
    "all",
    "would",
    "there",
    "their",
    "what",
    "so",
    "up",
    "out",
    "if",
    "about",
    "who",
    "get",
    "which",
    "go",
    "me",
    "when",
    "make",
    "can",
    "like",
    "time",
    "no",
    "just",
    "him",
    "know",
    "take",
    "people",
    "into",
    "year",
    "your",
    "good",
    "some",
    "could",
    "them",
    "see",
    "other",
    "than",
    "then",
    "now",
    "look",
    "only",
    "come",
    "its",
    "over",
    "think",
    "also",
    "back",
    "after",
    "use",
    "two",
    "how",
    "our",
    "work",
    "first",
    "well",
    "way",
    "even",
    "new",
    "want",
    "because",
    "any",
    "these",
    "give",
    "day",
    "most",
    "us",
    "is",
    "are",
    "was",
    "were",
    "has",
    "had",
    "been",
    "am",
    "ready",
    "here",
    "help",
    "please",
    "write",
    "chat",
    "send",
    "message",
    "text",
    "search",
    "press",
    "open",
    "close",
    "view",
    "edit",
    "save",
    "delete",
    "create",
    "start",
    "stop",
    "check",
    "review",
    "find",
    "read",
    "run",
    "file",
    "page",
    "app",
    "web",
    "tool",
    "user",
    "input",
    "mode",
    "screen",
    "code",
    "data",
    "test",
    "issue",
    "error",
    "word",
    "line",
    "paragraph",
    "sentence",
    "grammar",
    "spell",
    "correct",
    "fix",
    "tone",
    "formal",
    "clear",
    "fast",
    "free",
    "key",
    "setting",
    "privacy",
    "model",
    "ai",
    "assistant",
    "lingually",
    "chrome",
    "system",
    "click",
    "select",
    "type",
    "today",
    "tomorrow",
    "yesterday",
    "always",
    "never",
    "often",
    "sometimes",
    "very",
    "much",
    "many",
    "few",
    "little",
    "big",
    "small",
    "high",
    "low",
    "long",
    "short",
    "right",
    "wrong",
    "true",
    "false",
    "yes",
    "sure",
    "fine",
    "great",
    "best",
    "better",
    "worse",
    "worst",
    "more",
    "less",
    "least",
    "again",
    "already",
    "still",
    "yet",
    "maybe",
    "perhaps",
    "actually",
    "really",
    "simply",
    "quite",
    "rather",
    "pretty",
    "almost",
    "enough",
    "too",
    "both",
    "either",
    "neither",
    "each",
    "every",
    "own",
    "same",
    "such",
    "why",
    "where",
    "how",
    "while",
    "since",
    "until",
    "before",
    "during",
    "through",
    "across",
    "under",
    "above",
    "between",
    "among",
    "against",
    "without",
    "within",
    "around",
    "behind",
    "beyond",
    "upon",
    "towards",
    "near",
    "off",
    "down",
    "left",
    "front",
    "side",
    "center",
    "hello",
    "hi",
    "hey",
    "thanks",
    "thank",
    "welcome",
    "sorry",
    "excuse",
    "pardon",
    "bye",
    "question",
    "answer",
    "reason",
    "problem",
    "solution",
    "result",
    "action",
    "change",
    "point",
    "thing",
    "place",
    "part",
    "number",
    "group",
    "fact",
    "idea",
    "story",
    "life",
    "world",
    "hand",
    "eye",
    "head",
    "face",
    "voice",
    "sound",
    "mind",
    "heart",
    "body",
    "name",
    "call",
    "keep",
    "let",
    "begin",
    "seem",
    "help",
    "talk",
    "turn",
    "start",
    "show",
    "hear",
    "play",
    "move",
    "live",
    "believe",
    "hold",
    "bring",
    "happen",
    "must",
    "write",
    "provide",
    "sit",
    "stand",
    "lose",
    "pay",
    "meet",
    "include",
    "continue",
    "set",
    "learn",
    "lead",
    "understand",
    "watch",
    "follow",
    "stop",
    "allow",
    "add",
    "spend",
    "grow",
    "open",
    "walk",
    "win",
    "offer",
    "remember",
    "love",
    "consider",
    "appear",
    "buy",
    "wait",
    "serve",
    "die",
    "send",
    "expect",
    "build",
    "stay",
    "fall",
    "cut",
    "reach",
    "kill",
    "remain",
    "suggest",
    "raise",
    "pass",
    "sell",
    "require",
    "report",
    "decide",
    "pull"
  ]);
  function levenshteinDistance(a, b) {
    const m = a.length;
    const n = b.length;
    const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        if (a[i - 1] === b[j - 1]) {
          dp[i][j] = dp[i - 1][j - 1];
        } else {
          dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
        }
      }
    }
    return dp[m][n];
  }
  function findClosestWord(target) {
    let closest = null;
    let minDistance = 3;
    for (const word of COMMON_VOCABULARY) {
      if (Math.abs(word.length - target.length) > 2) continue;
      const dist = levenshteinDistance(target, word);
      if (dist < minDistance) {
        minDistance = dist;
        closest = word;
        if (dist === 1) break;
      }
    }
    return closest;
  }
  function isLikelyGibberishOrMisspelling(word) {
    if (word.length < 3) return false;
    const lower = word.toLowerCase();
    if (COMMON_VOCABULARY.has(lower) || DETERMINISTIC_TYPOS[lower]) return false;
    const rootS = lower.endsWith("s") ? lower.slice(0, -1) : "";
    const rootEd = lower.endsWith("ed") ? lower.slice(0, -2) : "";
    const rootIng = lower.endsWith("ing") ? lower.slice(0, -3) : "";
    const rootLy = lower.endsWith("ly") ? lower.slice(0, -2) : "";
    if (rootS && COMMON_VOCABULARY.has(rootS) || rootEd && COMMON_VOCABULARY.has(rootEd) || rootIng && COMMON_VOCABULARY.has(rootIng) || rootLy && COMMON_VOCABULARY.has(rootLy)) {
      return false;
    }
    if (/([a-zA-Z])\1\1/.test(lower)) return true;
    if (/^(hh|vv|jj|qq|xx|ww|yy|ii|uu)/.test(lower)) return true;
    if (/(hgg|ggu|zzk|xkz|qq|q[^u]|ii|uu)/.test(lower)) return true;
    if (!/[aeiouy]/.test(lower)) return true;
    if (lower.length >= 4 && !COMMON_VOCABULARY.has(lower)) {
      return true;
    }
    return false;
  }
  function runExtensionCheck(text, personalDictionary2 = /* @__PURE__ */ new Set()) {
    const suggestions = [];
    let idCounter = 1;
    if (!text || text.trim().length === 0) return suggestions;
    const standaloneIRegex = /(^|[\s(])i([\s),.?!]|$)/g;
    let match;
    while ((match = standaloneIRegex.exec(text)) !== null) {
      const prefix = match[1];
      const offset = match.index + prefix.length;
      suggestions.push({
        id: `ext_i_${idCounter++}`,
        category: "correctness",
        originalText: "i",
        replacementText: "I",
        explanation: "Capitalize the standalone personal pronoun 'I'.",
        offset,
        length: 1
      });
    }
    const repeatedRegex = /\b([a-zA-Z]+)\s+\1\b/gi;
    while ((match = repeatedRegex.exec(text)) !== null) {
      const rawWord = match[1];
      suggestions.push({
        id: `ext_rep_${idCounter++}`,
        category: "correctness",
        originalText: match[0],
        replacementText: rawWord,
        explanation: `Repeated word '${rawWord}'. Remove the duplicate.`,
        offset: match.index,
        length: match[0].length
      });
    }
    const wordRegex = /\b[a-zA-Z]+\b/g;
    while ((match = wordRegex.exec(text)) !== null) {
      const rawWord = match[0];
      const lower = rawWord.toLowerCase();
      if (personalDictionary2.has(lower)) continue;
      if (DETERMINISTIC_TYPOS[lower]) {
        const entry = DETERMINISTIC_TYPOS[lower];
        const isCapitalized = rawWord[0] === rawWord[0].toUpperCase() && rawWord[0] !== rawWord[0].toLowerCase();
        const replacement = isCapitalized ? entry.replacement.charAt(0).toUpperCase() + entry.replacement.slice(1) : entry.replacement;
        suggestions.push({
          id: `ext_typo_${idCounter++}`,
          category: "correctness",
          originalText: rawWord,
          replacementText: replacement,
          explanation: entry.explanation,
          offset: match.index,
          length: rawWord.length
        });
        continue;
      }
      if (isLikelyGibberishOrMisspelling(rawWord)) {
        const closest = findClosestWord(lower);
        const isCap = rawWord[0] === rawWord[0].toUpperCase();
        const rep = closest ? isCap ? closest.charAt(0).toUpperCase() + closest.slice(1) : closest : "check spelling";
        suggestions.push({
          id: `ext_gib_${idCounter++}`,
          category: "correctness",
          originalText: rawWord,
          replacementText: rep,
          explanation: closest ? `Possible misspelling. Did you mean '${rep}'?` : `Unrecognized word '${rawWord}'. Check spelling or add to dictionary.`,
          offset: match.index,
          length: rawWord.length
        });
      }
    }
    for (const item of DETERMINISTIC_CONFUSIONS) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_conf_${idCounter++}`,
          category: "correctness",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_CLARITY) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_clarity_${idCounter++}`,
          category: "clarity",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_ENGAGEMENT) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_eng_${idCounter++}`,
          category: "engagement",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    for (const item of DETERMINISTIC_DELIVERY) {
      while ((match = item.pattern.exec(text)) !== null) {
        suggestions.push({
          id: `ext_del_${idCounter++}`,
          category: "delivery",
          originalText: match[0],
          replacementText: item.replacement,
          explanation: item.explanation,
          offset: match.index,
          length: match[0].length
        });
      }
    }
    return suggestions.sort((a, b) => a.offset - b.offset);
  }
  function paraphraseText(text, mode = "standard") {
    if (!text || text.trim().length === 0) return text;
    let result = text;
    result = result.replace(/(^|[\s(])i([\s),.?!]|$)/g, "$1I$2");
    result = result.replace(/\bdefinately\b/gi, "definitely");
    result = result.replace(/\brecieve\b/gi, "receive");
    result = result.replace(/\bseperate\b/gi, "separate");
    result = result.replace(/\bteh\b/gi, "the");
    result = result.replace(/\boccured\b/gi, "occurred");
    if (mode === "formal") {
      result = result.replace(/\bcan't\b/gi, "cannot");
      result = result.replace(/\bdon't\b/gi, "do not");
      result = result.replace(/\bwon't\b/gi, "will not");
      result = result.replace(/\bit's\b/gi, "it is");
      result = result.replace(/\bthat's\b/gi, "that is");
      result = result.replace(/\bthere's\b/gi, "there is");
      result = result.replace(/\bwe're\b/gi, "we are");
      result = result.replace(/\byou're\b/gi, "you are");
      result = result.replace(/\bi'm\b/gi, "I am");
      result = result.replace(/\bi've\b/gi, "I have");
      result = result.replace(/\bi'll\b/gi, "I will");
      result = result.replace(/\bask\b/gi, "request");
      result = result.replace(/\bhelp\b/gi, "assist");
      result = result.replace(/\bneed\b/gi, "require");
      result = result.replace(/\bshow\b/gi, "demonstrate");
      result = result.replace(/\bget\b/gi, "obtain");
      result = result.replace(/\btell\b/gi, "inform");
      result = result.replace(/\bbuy\b/gi, "purchase");
      result = result.replace(/\bstart\b/gi, "commence");
      result = result.replace(/\bmake sure\b/gi, "ensure");
      result = result.replace(/\bcheck\b/gi, "verify");
    } else if (mode === "shorten") {
      result = result.replace(/\bin order to\b/gi, "to");
      result = result.replace(/\bat this point in time\b/gi, "now");
      result = result.replace(/\bdue to the fact that\b/gi, "because");
      result = result.replace(/\bhas the ability to\b/gi, "can");
      result = result.replace(/\bfor the purpose of\b/gi, "for");
      result = result.replace(/\bin the event that\b/gi, "if");
      result = result.replace(/\ba large number of\b/gi, "many");
      result = result.replace(/\ba small number of\b/gi, "few");
      result = result.replace(/\bwith the exception of\b/gi, "except");
      result = result.replace(/\btake into consideration\b/gi, "consider");
      result = result.replace(/\bmake a decision\b/gi, "decide");
      result = result.replace(/\breally\s+/gi, "");
      result = result.replace(/\bvery\s+/gi, "");
      result = result.replace(/\bquite\s+/gi, "");
    } else if (mode === "fluency") {
      result = result.replace(/\bin order to\b/gi, "to");
      result = result.replace(/\bvery good\b/gi, "superb");
      result = result.replace(/\bvery important\b/gi, "crucial");
      result = result.replace(/\bdue to the fact that\b/gi, "since");
      result = result.replace(/\bhas the ability to\b/gi, "can easily");
      result = result.replace(/\butilize\b/gi, "use");
    } else if (mode === "expand") {
      result = result.replace(/\bgood\b/gi, "thorough and well-crafted");
      result = result.replace(/\bhelp\b/gi, "provide comprehensive assistance with");
      result = result.replace(/\bimportant\b/gi, "essential to achieving the desired outcome");
      result = result.replace(/\bchange\b/gi, "refine and enhance");
      result = result.replace(/\bclear\b/gi, "unambiguous and transparent");
    } else {
      result = result.replace(/\bin order to\b/gi, "to");
      result = result.replace(/\bat this point in time\b/gi, "now");
      result = result.replace(/\bdue to the fact that\b/gi, "because");
      result = result.replace(/\butilize\b/gi, "use");
      result = result.replace(/\bvery good\b/gi, "exceptional");
    }
    return result;
  }

  // apps/chrome-extension/src/content.ts
  var activeElement = null;
  var currentSuggestions = [];
  var personalDictionary = /* @__PURE__ */ new Set();
  var isExtensionEnabled = true;
  var debounceTimer = null;
  var floatingBtn = null;
  var underlineLayer = null;
  var tooltipElement = null;
  var modalElement = null;
  var activeParaphraseMode = "standard";
  chrome.storage.sync.get(["lingually_enabled", "lingually_dictionary"], (res) => {
    if (res.lingually_enabled !== void 0) {
      isExtensionEnabled = Boolean(res.lingually_enabled);
    }
    if (Array.isArray(res.lingually_dictionary)) {
      personalDictionary = new Set(res.lingually_dictionary.map((w) => w.toLowerCase()));
    }
  });
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.lingually_enabled) {
      isExtensionEnabled = Boolean(changes.lingually_enabled.newValue);
      if (!isExtensionEnabled) {
        removeUI();
      }
    }
    if (changes.lingually_dictionary) {
      const list = changes.lingually_dictionary.newValue || [];
      personalDictionary = new Set(list.map((w) => w.toLowerCase()));
      if (activeElement) {
        checkActiveElement();
      }
    }
  });
  function isEditable(el) {
    if (!el) return false;
    if (el.closest(".lingually-modal") || el.closest(".lingually-tooltip") || el.closest(".lingually-floating-btn")) {
      return false;
    }
    const tag = el.tagName.toLowerCase();
    if (tag === "textarea") return true;
    if (tag === "input") {
      const inputType = el.type.toLowerCase();
      return ["text", "search", "email", "url", ""].includes(inputType);
    }
    return el.isContentEditable || el.getAttribute("contenteditable") === "true";
  }
  function getText(el) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      return el.value;
    }
    return el.innerText || el.textContent || "";
  }
  function setText(el, newText) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      const start = el.selectionStart;
      const end = el.selectionEnd;
      el.value = newText;
      if (start !== null && end !== null) {
        el.setSelectionRange(Math.min(start, newText.length), Math.min(end, newText.length));
      }
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else if (el.isContentEditable) {
      el.innerText = newText;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  function removeUI() {
    if (floatingBtn && floatingBtn.parentNode) {
      floatingBtn.parentNode.removeChild(floatingBtn);
      floatingBtn = null;
    }
    if (underlineLayer && underlineLayer.parentNode) {
      underlineLayer.parentNode.removeChild(underlineLayer);
      underlineLayer = null;
    }
    if (tooltipElement && tooltipElement.parentNode) {
      tooltipElement.parentNode.removeChild(tooltipElement);
      tooltipElement = null;
    }
    if (modalElement && modalElement.parentNode) {
      modalElement.parentNode.removeChild(modalElement);
      modalElement = null;
    }
  }
  function updatePositions() {
    if (!activeElement) return;
    updateFloatingBtnPosition();
    renderUnderlines();
  }
  function updateFloatingBtnPosition() {
    if (!floatingBtn || !activeElement) return;
    const rect = activeElement.getBoundingClientRect();
    const scrollX = window.scrollX || window.pageXOffset;
    const scrollY = window.scrollY || window.pageYOffset;
    const top = scrollY + rect.bottom - (rect.height > 44 ? 36 : 30);
    const left = scrollX + rect.right - 36;
    floatingBtn.style.top = `${Math.max(scrollY + 4, top)}px`;
    floatingBtn.style.left = `${Math.max(scrollX + 4, left)}px`;
  }
  function renderFloatingBtn(count) {
    if (!activeElement || !isExtensionEnabled) {
      removeUI();
      return;
    }
    if (!floatingBtn) {
      floatingBtn = document.createElement("div");
      floatingBtn.className = "lingually-floating-btn";
      floatingBtn.title = "Lingually Writing Assistant";
      floatingBtn.innerHTML = `
      <svg class="lingually-floating-icon-svg" viewBox="0 0 24 24" fill="none" stroke="#0268cc" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 20h9"></path>
        <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
      </svg>
      <div class="lingually-floating-badge" id="lingually-badge-el"></div>
    `;
      floatingBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        e.preventDefault();
        toggleModal();
      });
      document.body.appendChild(floatingBtn);
    }
    const badgeEl = floatingBtn.querySelector("#lingually-badge-el");
    if (badgeEl) {
      if (count > 0) {
        badgeEl.className = "lingually-floating-badge";
        badgeEl.textContent = count > 99 ? "99+" : String(count);
        badgeEl.style.display = "flex";
      } else {
        badgeEl.className = "lingually-floating-badge lingually-floating-badge-clean";
        badgeEl.textContent = "";
        badgeEl.style.display = "block";
      }
    }
    updateFloatingBtnPosition();
  }
  function ensureUnderlineLayer() {
    if (!underlineLayer) {
      underlineLayer = document.createElement("div");
      underlineLayer.className = "lingually-underline-layer";
      document.body.appendChild(underlineLayer);
    }
    underlineLayer.innerHTML = "";
  }
  function renderUnderlines() {
    if (!activeElement || !isExtensionEnabled || currentSuggestions.length === 0) {
      if (underlineLayer) underlineLayer.innerHTML = "";
      return;
    }
    ensureUnderlineLayer();
    if (!underlineLayer) return;
    const scrollX = window.scrollX || window.pageXOffset;
    const scrollY = window.scrollY || window.pageYOffset;
    const elemRect = activeElement.getBoundingClientRect();
    if (activeElement.isContentEditable) {
      renderContentEditableUnderlines(activeElement, scrollX, scrollY);
    } else if (activeElement instanceof HTMLTextAreaElement || activeElement instanceof HTMLInputElement) {
      renderInputUnderlines(activeElement, elemRect, scrollX, scrollY);
    }
  }
  function renderContentEditableUnderlines(container, scrollX, scrollY) {
    if (!underlineLayer) return;
    const textNodes = [];
    let currentOffset = 0;
    function collectTextNodes(node) {
      if (node.nodeType === Node.TEXT_NODE) {
        const text = node.textContent || "";
        textNodes.push({
          node,
          start: currentOffset,
          end: currentOffset + text.length
        });
        currentOffset += text.length;
      } else {
        for (let i = 0; i < node.childNodes.length; i++) {
          collectTextNodes(node.childNodes[i]);
        }
      }
    }
    collectTextNodes(container);
    currentSuggestions.forEach((s) => {
      const sStart = s.offset;
      const sEnd = s.offset + s.length;
      for (const t of textNodes) {
        if (sStart < t.end && sEnd > t.start) {
          const nodeStart = Math.max(0, sStart - t.start);
          const nodeEnd = Math.min(t.node.length, sEnd - t.start);
          try {
            const range = document.createRange();
            range.setStart(t.node, nodeStart);
            range.setEnd(t.node, nodeEnd);
            const rects = range.getClientRects();
            for (let i = 0; i < rects.length; i++) {
              const r = rects[i];
              if (r.width === 0 || r.height === 0) continue;
              const u = document.createElement("div");
              u.className = `lingually-underline lingually-underline-${s.category}`;
              u.style.top = `${scrollY + r.bottom - 3}px`;
              u.style.left = `${scrollX + r.left}px`;
              u.style.width = `${r.width}px`;
              u.addEventListener("mouseenter", (e) => {
                e.stopPropagation();
                showTooltip(s, r, scrollX, scrollY);
              });
              u.addEventListener("click", (e) => {
                e.stopPropagation();
                showTooltip(s, r, scrollX, scrollY);
              });
              underlineLayer?.appendChild(u);
            }
          } catch {
          }
        }
      }
    });
  }
  function renderInputUnderlines(input, elemRect, scrollX, scrollY) {
    if (!underlineLayer) return;
    const style = window.getComputedStyle(input);
    const paddingTop = parseFloat(style.paddingTop) || 0;
    const paddingLeft = parseFloat(style.paddingLeft) || 0;
    const fontSize = parseFloat(style.fontSize) || 14;
    const lineHeight = parseFloat(style.lineHeight) || fontSize * 1.4;
    const fullText = input.value;
    currentSuggestions.forEach((s) => {
      const textBefore = fullText.slice(0, s.offset);
      const lines = textBefore.split("\n");
      const lineIndex = lines.length - 1;
      const colIndex = lines[lineIndex].length;
      const charWidth = fontSize * 0.58;
      const wordWidth = Math.max(14, s.length * charWidth);
      const left = elemRect.left + paddingLeft + colIndex * charWidth - input.scrollLeft;
      const top = elemRect.top + paddingTop + (lineIndex + 1) * lineHeight - input.scrollTop;
      if (left >= elemRect.left && left + wordWidth <= elemRect.right && top <= elemRect.bottom + 4) {
        const u = document.createElement("div");
        u.className = `lingually-underline lingually-underline-${s.category}`;
        u.style.top = `${scrollY + top - 2}px`;
        u.style.left = `${scrollX + left}px`;
        u.style.width = `${wordWidth}px`;
        const r = {
          left,
          top: top - lineHeight,
          bottom: top,
          right: left + wordWidth,
          width: wordWidth,
          height: lineHeight
        };
        u.addEventListener("mouseenter", (e) => {
          e.stopPropagation();
          showTooltip(s, r, scrollX, scrollY);
        });
        u.addEventListener("click", (e) => {
          e.stopPropagation();
          showTooltip(s, r, scrollX, scrollY);
        });
        underlineLayer?.appendChild(u);
      }
    });
  }
  function showTooltip(s, rect, scrollX, scrollY) {
    if (tooltipElement && tooltipElement.parentNode) {
      tooltipElement.parentNode.removeChild(tooltipElement);
      tooltipElement = null;
    }
    tooltipElement = document.createElement("div");
    tooltipElement.className = "lingually-tooltip";
    const top = scrollY + rect.bottom + 6;
    const left = Math.min(scrollX + rect.left, window.innerWidth + scrollX - 310);
    tooltipElement.style.top = `${top}px`;
    tooltipElement.style.left = `${Math.max(scrollX + 8, left)}px`;
    tooltipElement.innerHTML = `
    <div class="lingually-tooltip-header">
      <span class="lingually-cat-badge lingually-cat-${s.category}">${s.category}</span>
      <span style="font-size: 11px; color: #94a3b8; cursor: pointer;" id="tooltip-close-btn">&times;</span>
    </div>
    <div class="lingually-tooltip-body">
      <span class="lingually-strikethrough">${s.originalText}</span>
      <span class="lingually-arrow">&rarr;</span>
      <span class="lingually-suggested">${s.replacementText}</span>
    </div>
    <div class="lingually-tooltip-reason">${s.explanation}</div>
    <div class="lingually-tooltip-actions">
      <button class="lingually-btn-accept" id="tooltip-accept-btn">Accept</button>
      <button class="lingually-btn-dismiss" id="tooltip-dismiss-btn">Ignore</button>
    </div>
    <button class="lingually-btn-dict-link" id="tooltip-dict-btn">Add "${s.originalText}" to dictionary</button>
  `;
    document.body.appendChild(tooltipElement);
    tooltipElement.querySelector("#tooltip-accept-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      applySuggestion(s);
      dismissTooltip();
    });
    tooltipElement.querySelector("#tooltip-dismiss-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dismissSuggestion(s);
      dismissTooltip();
    });
    tooltipElement.querySelector("#tooltip-close-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dismissTooltip();
    });
    tooltipElement.querySelector("#tooltip-dict-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      addToDictionary(s.originalText);
      dismissTooltip();
    });
  }
  function dismissTooltip() {
    if (tooltipElement && tooltipElement.parentNode) {
      tooltipElement.parentNode.removeChild(tooltipElement);
      tooltipElement = null;
    }
  }
  function toggleModal() {
    if (modalElement) {
      closeModal();
    } else {
      openModal();
    }
  }
  function openModal() {
    if (!activeElement) return;
    if (modalElement) closeModal();
    modalElement = document.createElement("div");
    modalElement.className = "lingually-modal";
    const rect = activeElement.getBoundingClientRect();
    const scrollX = window.scrollX || window.pageXOffset;
    const scrollY = window.scrollY || window.pageYOffset;
    let top = scrollY + rect.bottom + 8;
    let left = scrollX + rect.right - 380;
    if (left < scrollX + 16) left = scrollX + 16;
    if (top + 460 > window.innerHeight + scrollY) {
      top = Math.max(scrollY + 16, scrollY + rect.top - 460);
    }
    modalElement.style.top = `${top}px`;
    modalElement.style.left = `${left}px`;
    renderModalContent("review");
    document.body.appendChild(modalElement);
  }
  function closeModal() {
    if (modalElement && modalElement.parentNode) {
      modalElement.parentNode.removeChild(modalElement);
      modalElement = null;
    }
  }
  function renderModalContent(activeTab) {
    if (!modalElement || !activeElement) return;
    const currentText = getText(activeElement);
    const score = Math.max(50, 100 - currentSuggestions.length * 8);
    modalElement.innerHTML = `
    <div class="lingually-modal-header">
      <div class="lingually-modal-brand">
        <svg style="width: 16px; height: 16px;" viewBox="0 0 24 24" fill="none" stroke="#0268cc" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M12 20h9"></path>
          <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
        </svg>
        <span>Lingually Assistant</span>
      </div>
      <button class="lingually-modal-close" id="modal-close-x">&times;</button>
    </div>

    <div class="lingually-modal-tabs">
      <button class="lingually-tab-btn ${activeTab === "review" ? "active" : ""}" id="tab-btn-review">
        01 // REVIEW (${currentSuggestions.length})
      </button>
      <button class="lingually-tab-btn ${activeTab === "paraphrase" ? "active" : ""}" id="tab-btn-paraphrase">
        02 // PARAPHRASE
      </button>
    </div>

    <div class="lingually-modal-content" id="modal-tab-content"></div>
  `;
    modalElement.querySelector("#modal-close-x")?.addEventListener("click", closeModal);
    modalElement.querySelector("#tab-btn-review")?.addEventListener("click", () => renderModalContent("review"));
    modalElement.querySelector("#tab-btn-paraphrase")?.addEventListener("click", () => renderModalContent("paraphrase"));
    const contentBox = modalElement.querySelector("#modal-tab-content");
    if (activeTab === "review") {
      if (currentSuggestions.length === 0) {
        contentBox.innerHTML = `
        <div class="lingually-empty-review">
          <div class="lingually-empty-icon">&#10003;</div>
          <div style="font-weight: 700; color: #0f172a; margin-bottom: 4px;">Writing looks exceptional!</div>
          <div>0 grammar or spelling issues detected in this field.</div>
        </div>
      `;
      } else {
        contentBox.innerHTML = `
        <div class="lingually-score-banner">
          <div>Writing Health Score: <span class="lingually-score-value">${score}/100</span></div>
          ${currentSuggestions.length > 1 ? `<button class="lingually-btn-fix-all" id="btn-fix-all">Fix All (${currentSuggestions.length})</button>` : ""}
        </div>
        <div class="lingually-issues-list" id="modal-issues-list"></div>
      `;
        const listEl = contentBox.querySelector("#modal-issues-list");
        currentSuggestions.forEach((s) => {
          const item = document.createElement("div");
          item.className = "lingually-issue-card";
          item.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <span class="lingually-cat-badge lingually-cat-${s.category}">${s.category}</span>
          </div>
          <div class="lingually-tooltip-body" style="margin: 4px 0;">
            <span class="lingually-strikethrough">${s.originalText}</span>
            <span class="lingually-arrow">&rarr;</span>
            <span class="lingually-suggested">${s.replacementText}</span>
          </div>
          <div class="lingually-tooltip-reason" style="margin-bottom: 8px;">${s.explanation}</div>
          <div class="lingually-tooltip-actions">
            <button class="lingually-btn-accept" data-id="${s.id}">Accept</button>
            <button class="lingually-btn-dismiss" data-id="${s.id}">Ignore</button>
          </div>
        `;
          item.querySelector(".lingually-btn-accept")?.addEventListener("click", (e) => {
            e.stopPropagation();
            applySuggestion(s);
            renderModalContent("review");
          });
          item.querySelector(".lingually-btn-dismiss")?.addEventListener("click", (e) => {
            e.stopPropagation();
            dismissSuggestion(s);
            renderModalContent("review");
          });
          listEl.appendChild(item);
        });
        contentBox.querySelector("#btn-fix-all")?.addEventListener("click", (e) => {
          e.stopPropagation();
          fixAllSuggestions();
          renderModalContent("review");
        });
      }
    } else {
      contentBox.innerHTML = `
      <div style="font-size: 11px; font-weight: 600; color: #475569; margin-bottom: 6px;">PARAPHRASE MODE</div>
      <div class="lingually-mode-selector">
        <button class="lingually-mode-chip ${activeParaphraseMode === "standard" ? "active" : ""}" data-mode="standard">Standard</button>
        <button class="lingually-mode-chip ${activeParaphraseMode === "fluency" ? "active" : ""}" data-mode="fluency">Fluency</button>
        <button class="lingually-mode-chip ${activeParaphraseMode === "formal" ? "active" : ""}" data-mode="formal">Formal</button>
        <button class="lingually-mode-chip ${activeParaphraseMode === "shorten" ? "active" : ""}" data-mode="shorten">Shorten</button>
        <button class="lingually-mode-chip ${activeParaphraseMode === "expand" ? "active" : ""}" data-mode="expand">Expand</button>
      </div>

      <div style="font-size: 11px; font-weight: 600; color: #475569; margin-bottom: 4px;">ORIGINAL TEXT</div>
      <div class="lingually-paraphrase-box" id="para-input-preview">${escapeHtml(currentText)}</div>

      <button class="lingually-btn-paraphrase" id="btn-run-paraphrase">
        <svg style="width: 14px; height: 14px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="23 4 23 10 17 10"></polyline>
          <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
        </svg>
        <span>Paraphrase with Lingually</span>
      </button>

      <div class="lingually-paraphrase-output" id="para-output-area" style="display: none;">
        <div style="font-size: 11px; font-weight: 600; color: #059669; margin-bottom: 4px;">REWRITTEN VERSION</div>
        <div class="lingually-paraphrase-box" id="para-output-text" style="background: #f0fdf4; border-color: #bbf7d0;"></div>
        <div class="lingually-paraphrase-actions">
          <button class="lingually-btn-replace" id="btn-insert-page">Replace in Text Field</button>
          <button class="lingually-btn-copy" id="btn-copy-para">Copy</button>
        </div>
      </div>
    `;
      contentBox.querySelectorAll(".lingually-mode-chip").forEach((chip) => {
        chip.addEventListener("click", () => {
          contentBox.querySelectorAll(".lingually-mode-chip").forEach((c) => c.classList.remove("active"));
          chip.classList.add("active");
          activeParaphraseMode = chip.getAttribute("data-mode");
        });
      });
      let currentParaphraseOutput = "";
      contentBox.querySelector("#btn-run-paraphrase")?.addEventListener("click", () => {
        const btn = contentBox.querySelector("#btn-run-paraphrase");
        btn.innerHTML = `<span>Paraphrasing...</span>`;
        btn.disabled = true;
        setTimeout(() => {
          currentParaphraseOutput = paraphraseText(currentText, activeParaphraseMode);
          const outputArea = contentBox.querySelector("#para-output-area");
          const outputText = contentBox.querySelector("#para-output-text");
          outputText.textContent = currentParaphraseOutput;
          outputArea.style.display = "block";
          btn.disabled = false;
          btn.innerHTML = `
          <svg style="width: 14px; height: 14px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"></polyline>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
          </svg>
          <span>Re-paraphrase</span>
        `;
        }, 250);
      });
      contentBox.querySelector("#btn-insert-page")?.addEventListener("click", () => {
        if (activeElement && currentParaphraseOutput) {
          setText(activeElement, currentParaphraseOutput);
          checkActiveElement();
          closeModal();
        }
      });
      contentBox.querySelector("#btn-copy-para")?.addEventListener("click", () => {
        if (currentParaphraseOutput) {
          navigator.clipboard.writeText(currentParaphraseOutput);
          const copyBtn = contentBox.querySelector("#btn-copy-para");
          copyBtn.textContent = "Copied!";
          setTimeout(() => {
            copyBtn.textContent = "Copy";
          }, 1500);
        }
      });
    }
  }
  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function applySuggestion(s) {
    if (!activeElement) return;
    const fullText = getText(activeElement);
    const before = fullText.slice(0, s.offset);
    const after = fullText.slice(s.offset + s.length);
    const updated = before + s.replacementText + after;
    setText(activeElement, updated);
    checkActiveElement();
  }
  function fixAllSuggestions() {
    if (!activeElement || currentSuggestions.length === 0) return;
    let fullText = getText(activeElement);
    const sorted = [...currentSuggestions].sort((a, b) => b.offset - a.offset);
    for (const s of sorted) {
      const before = fullText.slice(0, s.offset);
      const after = fullText.slice(s.offset + s.length);
      fullText = before + s.replacementText + after;
    }
    setText(activeElement, fullText);
    checkActiveElement();
  }
  function dismissSuggestion(s) {
    currentSuggestions = currentSuggestions.filter((item) => item.id !== s.id);
    renderFloatingBtn(currentSuggestions.length);
    renderUnderlines();
  }
  function addToDictionary(word) {
    const cleanWord = word.trim().toLowerCase();
    personalDictionary.add(cleanWord);
    chrome.storage.sync.get(["lingually_dictionary"], (res) => {
      const existing = res.lingually_dictionary || [];
      if (!existing.includes(cleanWord)) {
        chrome.storage.sync.set({ lingually_dictionary: [...existing, cleanWord] });
      }
    });
    checkActiveElement();
  }
  function checkActiveElement() {
    if (!activeElement || !isExtensionEnabled) {
      removeUI();
      return;
    }
    const text = getText(activeElement);
    if (text.length < 2) {
      currentSuggestions = [];
      renderFloatingBtn(0);
      renderUnderlines();
      return;
    }
    currentSuggestions = runExtensionCheck(text, personalDictionary);
    renderFloatingBtn(currentSuggestions.length);
    renderUnderlines();
  }
  document.addEventListener(
    "focusin",
    (event) => {
      const target = event.target;
      if (isEditable(target)) {
        activeElement = target;
        checkActiveElement();
      }
    },
    true
  );
  document.addEventListener(
    "input",
    (event) => {
      const target = event.target;
      if (isEditable(target)) {
        activeElement = target;
        if (debounceTimer) clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
          checkActiveElement();
        }, 300);
      }
    },
    true
  );
  document.addEventListener("click", (event) => {
    const target = event.target;
    if (tooltipElement && !tooltipElement.contains(target) && !target.classList.contains("lingually-underline")) {
      dismissTooltip();
    }
    if (modalElement && !modalElement.contains(target) && floatingBtn && !floatingBtn.contains(target) && !target.classList.contains("lingually-floating-btn")) {
      closeModal();
    }
  });
  window.addEventListener("scroll", updatePositions, { passive: true });
  window.addEventListener("resize", updatePositions, { passive: true });
})();
